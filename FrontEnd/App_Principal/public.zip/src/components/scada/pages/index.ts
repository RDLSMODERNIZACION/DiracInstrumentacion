export { OverviewGrid } from "./OverviewGrid";

// re-export directo desde src/components/scada/utils.ts
export { labelOfTab } from "../utils";
