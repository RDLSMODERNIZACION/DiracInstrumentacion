// src/lib/auth.tsx
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

type AuthState = {
  email: string | null;
  basicToken: string | null; // "Basic <b64(email:password)>"
};

type AuthContextType = {
  isAuthenticated: boolean;
  email: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  getAuthHeader: () => Record<string, string>;
};

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEY = "dirac.basic";

function buildBasicToken(email: string, password: string) {
  const b64 = btoa(`${email}:${password}`);
  return `Basic ${b64}`;
}

function getApiBase() {
  // Si servís el front desde Vercel y el backend en Render,
  // seteá VITE_API_BASE en el build del front (por ej: https://diracinstrumentacion.onrender.com).
  return (import.meta as any)?.env?.VITE_API_BASE || window.location.origin;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>(() => {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return { email: null, basicToken: null };
    try {
      return JSON.parse(raw) as AuthState;
    } catch {
      return { email: null, basicToken: null };
    }
  });

  useEffect(() => {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const getAuthHeader = useCallback(() => {
    return state.basicToken ? { Authorization: state.basicToken } : {};
  }, [state.basicToken]);

  const login = useCallback(async (email: string, password: string) => {
    const token = buildBasicToken(email, password);
    // Validamos credenciales con un ping a un endpoint protegido
    const res = await fetch(`${getApiBase()}/dirac/me/locations`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
    });
    if (!res.ok) {
      throw new Error(res.status === 401 ? "Credenciales inválidas" : `Error ${res.status}`);
    }
    setState({ email, basicToken: token });
  }, []);

  const logout = useCallback(() => {
    setState({ email: null, basicToken: null });
    sessionStorage.removeItem(STORAGE_KEY);
    // Opcional: window.location.reload();
  }, []);

  const value = useMemo<AuthContextType>(() => ({
    isAuthenticated: !!state.basicToken,
    email: state.email,
    login,
    logout,
    getAuthHeader,
  }), [state.basicToken, state.email, login, logout, getAuthHeader]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

// Helper para fetch con auth ya inyectado
export function useAuthedFetch() {
  const { getAuthHeader } = useAuth();
  const apiBase = getApiBase();
  return useCallback(async (path: string, init: RequestInit = {}) => {
    const headers = { "Content-Type": "application/json", ...(init.headers || {}), ...getAuthHeader() };
    const res = await fetch(`${apiBase}${path}`, { ...init, headers });
    return res;
  }, [getAuthHeader, apiBase]);
}
