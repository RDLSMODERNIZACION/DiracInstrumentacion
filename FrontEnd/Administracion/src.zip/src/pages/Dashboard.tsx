import React from "react";
export default function Dashboard() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Panel</h1>
      <p className="text-slate-600">Usá el menú de la izquierda para administrar.</p>
    </div>
  );
}
