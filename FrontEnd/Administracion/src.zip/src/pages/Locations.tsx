// src/pages/Locations.tsx
import React, { useEffect, useMemo, useState } from "react";
import Section from "../components/Section";
import { useApi } from "../lib/api";
import SlideOver from "../components/SlideOver";
import LocationEditor from "../components/LocationEditor";

type Location = {
  id: number;
  name: string;
  company_id?: number | null;
  address?: string | null;
  lat?: number | null;
  lon?: number | null;
};

type CompanyRow = { id: number; name: string; status?: string };

export default function Locations() {
  const { getJSON, postJSON } = useApi();

  // Listado
  const [items, setItems] = useState<Location[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // Crear
  const [name, setName] = useState("");
  const [createCompanyId, setCreateCompanyId] = useState<number | "">("");

  // Filtros
  const [companies, setCompanies] = useState<CompanyRow[]>([]);
  const [filterCompanyId, setFilterCompanyId] = useState<number | "">("");
  const [filterUserEmail, setFilterUserEmail] = useState("");
  const [showOnlyExplicit, setShowOnlyExplicit] = useState(false); // sólo para vista por usuario

  // Editor
  const [editing, setEditing] = useState<Location | null>(null);

  // ---- cargar empresas para selects (crear + filtros)
  async function loadCompanies() {
    const rows: CompanyRow[] = await getJSON("/dirac/admin/companies");
    setCompanies(rows);
  }

  // ---- cargar listado según filtros
  async function load() {
    setLoading(true);
    setErr(null);
    try {
      // Filtro por usuario (opcionalmente acotado por empresa)
      if (filterUserEmail.trim()) {
        const u = await getJSON(
          `/dirac/admin/users?email=${encodeURIComponent(filterUserEmail.trim().toLowerCase())}`
        );

        if (!u?.id) {
          setItems([]);
          setErr("Usuario no encontrado");
          setLoading(false);
          return;
        }

        const qs =
          filterCompanyId !== "" ? `?company_id=${Number(filterCompanyId)}` : "";
        const acc = await getJSON(`/dirac/admin/users/${u.id}/locations${qs}`);

        // Unificamos efectivas y explícitas, y opcionalmente filtramos "sólo explícitas"
        const effective = Array.isArray(acc?.effective) ? acc.effective : [];
        const explicit = Array.isArray(acc?.explicit) ? acc.explicit : [];

        const selected = showOnlyExplicit ? explicit : [...effective, ...explicit];

        // Normalizamos a Location (tenemos id, name y company_id)
        const byId = new Map<number, Location>();
        for (const r of selected) {
          const id = Number(r.location_id);
          if (!byId.has(id)) {
            byId.set(id, {
              id,
              name: r.location_name ?? `Loc ${id}`,
              company_id: r.company_id ?? null,
            });
          }
        }
        setItems(Array.from(byId.values()).sort((a, b) => a.id - b.id));
        setLoading(false);
        return;
      }

      // Filtro por empresa
      if (filterCompanyId !== "") {
        const rows = await getJSON(
          `/dirac/admin/locations?company_id=${Number(filterCompanyId)}`
        );
        setItems(rows);
        setLoading(false);
        return;
      }

      // Sin filtros: todas
      const rows = await getJSON("/dirac/admin/locations");
      setItems(rows);
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  // inicial
  useEffect(() => {
    loadCompanies();
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- crear localización
  async function create() {
    setErr(null);
    try {
      const payload: any = { name: name.trim() };
      if (!payload.name) {
        setErr("Ingresá un nombre");
        return;
      }
      if (createCompanyId !== "") payload.company_id = Number(createCompanyId);
      await postJSON("/dirac/locations", payload);
      setName("");
      setCreateCompanyId("");
      await load();
    } catch (e: any) {
      setErr(e?.message || String(e));
    }
  }

  // ---- utilidades
  const companyOpts = useMemo(
    () =>
      companies
        .slice()
        .sort((a, b) => a.name.localeCompare(b.name))
        .map((c) => ({ id: c.id, label: `${c.name} #${c.id}` })),
    [companies]
  );

  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Localizaciones</h1>

      {/* Filtros */}
      <Section title="Filtros" right={null}>
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <div className="text-xs text-slate-500">Empresa</div>
            <select
              className="border rounded px-2 py-1"
              value={filterCompanyId}
              onChange={(e) =>
                setFilterCompanyId(
                  e.target.value === "" ? "" : Number(e.target.value)
                )
              }
            >
              <option value="">(todas)</option>
              {companyOpts.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="text-xs text-slate-500">Usuario (email)</div>
            <input
              className="border rounded px-2 py-1"
              value={filterUserEmail}
              onChange={(e) => setFilterUserEmail(e.target.value)}
              placeholder="usuario@example.com"
            />
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={showOnlyExplicit}
              onChange={(e) => setShowOnlyExplicit(e.target.checked)}
              disabled={!filterUserEmail.trim()}
            />
            Sólo accesos explícitos
          </label>

          <div className="flex gap-2">
            <button
              onClick={load}
              className="px-3 py-1.5 rounded bg-slate-900 text-white"
            >
              Aplicar
            </button>
            <button
              onClick={async () => {
                setFilterCompanyId("");
                setFilterUserEmail("");
                setShowOnlyExplicit(false);
                await load();
              }}
              className="px-3 py-1.5 rounded bg-slate-200"
            >
              Limpiar
            </button>
          </div>
        </div>
        {err && <div className="text-sm text-red-600 mt-2">{err}</div>}
      </Section>

      {/* Crear */}
      <Section title="Crear localización" right={null}>
        <div className="flex items-end gap-3 flex-wrap">
          <div>
            <div className="text-xs text-slate-500">Nombre</div>
            <input
              className="border rounded px-2 py-1"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej. Planta Oeste"
            />
          </div>
          <div>
            <div className="text-xs text-slate-500">Empresa (opcional)</div>
            <select
              className="border rounded px-2 py-1"
              value={createCompanyId}
              onChange={(e) =>
                setCreateCompanyId(
                  e.target.value === "" ? "" : Number(e.target.value)
                )
              }
            >
              <option value="">(sin empresa)</option>
              {companyOpts.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={create}
            className="px-3 py-1.5 rounded bg-blue-600 text-white"
          >
            Crear
          </button>
        </div>
      </Section>

      {/* Listado */}
      <Section
        title="Listado (click en una fila para editar)"
        right={
          loading ? (
            <span className="text-xs text-slate-500">Cargando…</span>
          ) : null
        }
      >
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left">
              <th className="px-2 py-1">ID</th>
              <th className="px-2 py-1">Nombre</th>
              <th className="px-2 py-1">Empresa</th>
            </tr>
          </thead>
          <tbody>
            {items.map((l) => (
              <tr
                key={l.id}
                className="border-t hover:bg-slate-50 cursor-pointer"
                onClick={() => setEditing(l)}
              >
                <td className="px-2 py-1">{l.id}</td>
                <td className="px-2 py-1">{l.name}</td>
                <td className="px-2 py-1">{l.company_id ?? "—"}</td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={3} className="px-2 py-6 text-center text-slate-500">
                  {loading ? "Cargando…" : "Sin localizaciones"}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Section>

      {/* Editor */}
      <SlideOver
        open={!!editing}
        title={editing ? `Editar localización #${editing.id}` : ""}
        onClose={() => setEditing(null)}
      >
        {editing && (
          <LocationEditor
            location={editing as any}
            onSaved={async () => {
              setEditing(null);
              await load();
            }}
            onClose={() => setEditing(null)}
          />
        )}
      </SlideOver>
    </div>
  );
}
