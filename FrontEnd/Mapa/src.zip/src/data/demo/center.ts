// src/data/demo/center.ts
import type { LatLng } from "./types";

export const CENTER: LatLng = [-37.4036, -68.9360];
