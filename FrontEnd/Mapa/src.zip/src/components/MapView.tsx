import React from "react";
import {
  MapContainer,
  Marker,
  Popup,
  Polygon,
  TileLayer,
  Tooltip,
  ZoomControl,
  useMap,
  useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import { barrios, edges, zones, CENTER, type Asset, type Zone } from "../data/demo";

import { type LatLng } from "../lib/geo";
import { centroid } from "../lib/geoUtils";
import { focusPointIcon, locationMarkerIcon } from "../lib/mapIcons";
import { FlyTo } from "./FlyTo";

// ✅ Pipes backend + editor
import PipesLayer, { type PipeConnectivityStats, type SimRunResponse } from "./PipesLayer";
import PipeEditDrawer from "./PipeEditDrawer";
import PipeGeometryEditor from "./PipeGeometryEditor";

// ✅ Connect drawer
import PipeConnectDrawer from "./PipeConnectDrawer";

// ✅ Curvas visuales / topografía
import ContourVisualLayer from "./ContourVisualLayer";

// ✅ Puntitos de presión
import PressureNodesLayer from "./PressureNodesLayer";

// ✅ Create / Delete
import { createPipe, deletePipe, fetchNodes } from "../services/mapasagua";

// ✅ Sim API
import { runSim } from "../features/mapa/services/simApi";

export type ViewMode = "ALL" | "ZONES" | "PIPES" | "BARRIOS";

type SimMode = "topografico" | "hidraulico_suave";

/* ---------------------------
   Zoom watcher
--------------------------- */
function ZoomWatcher({ onZoom }: { onZoom: (z: number) => void }) {
  useMapEvents({
    zoomend: (e) => onZoom(e.target.getZoom()),
    moveend: (e) => onZoom(e.target.getZoom()),
  });

  return null;
}

/* ---------------------------
   Click en mapa => limpiar selección/cerrar modales
--------------------------- */
function MapClickClear({
  onClear,
  enabled = true,
}: {
  onClear: () => void;
  enabled?: boolean;
}) {
  useMapEvents({
    click: (e: any) => {
      if (!enabled) return;

      const t = e?.originalEvent?.target as any;
      if (!t) return;

      if (t.closest?.(".leaflet-popup")) return;

      if (
        t.closest?.(".leaflet-pm-draggable") ||
        t.closest?.(".leaflet-pm-marker") ||
        t.closest?.(".leaflet-pm-icon-marker") ||
        t.closest?.(".leaflet-pm-vertex") ||
        t.closest?.(".leaflet-pm-middle-marker") ||
        t.closest?.(".leaflet-pm-edit-marker")
      ) {
        return;
      }

      onClear();
    },
  });

  return null;
}

export type FocusPair =
  | {
      a: { label: string; pos: LatLng };
      b: { label: string; pos: LatLng };
    }
  | null;

/* ---------------------------
   Helpers barrios
--------------------------- */
function pressureLabelForBarrio(b: any): { label: string; tone: "good" | "mid" | "bad" | "na" } {
  const m = (b?.meta ?? {}) as any;

  const kpa = typeof m.presion_kpa === "number" ? m.presion_kpa : null;
  const bar = typeof m.presion_bar === "number" ? m.presion_bar : null;
  const pct = typeof m.presion_pct === "number" ? m.presion_pct : null;

  if (bar != null) {
    if (bar >= 2.2) return { label: `Presión: Buena (${bar.toFixed(1)} bar)`, tone: "good" };
    if (bar >= 1.6) return { label: `Presión: Media (${bar.toFixed(1)} bar)`, tone: "mid" };
    return { label: `Presión: Mala (${bar.toFixed(1)} bar)`, tone: "bad" };
  }

  if (kpa != null) {
    if (kpa >= 220) return { label: `Presión: Buena (${Math.round(kpa)} kPa)`, tone: "good" };
    if (kpa >= 160) return { label: `Presión: Media (${Math.round(kpa)} kPa)`, tone: "mid" };
    return { label: `Presión: Mala (${Math.round(kpa)} kPa)`, tone: "bad" };
  }

  if (pct != null) {
    if (pct >= 75) return { label: `Presión: Buena (${Math.round(pct)}%)`, tone: "good" };
    if (pct >= 45) return { label: `Presión: Media (${Math.round(pct)}%)`, tone: "mid" };
    return { label: `Presión: Mala (${Math.round(pct)}%)`, tone: "bad" };
  }

  return { label: "Presión: N/D", tone: "na" };
}

/* ---------------------------
   Fit helpers
--------------------------- */
function FitToRoute({
  dashedEdgeIdsExtra,
  assetsById,
  enabled,
}: {
  dashedEdgeIdsExtra?: Set<string>;
  assetsById: Map<string, Asset>;
  enabled: boolean;
}) {
  const map = useMap();

  React.useEffect(() => {
    if (!enabled) return;
    if (!dashedEdgeIdsExtra || dashedEdgeIdsExtra.size === 0) return;

    const pts: [number, number][] = [];

    for (const e of edges) {
      if (!dashedEdgeIdsExtra.has(e.id)) continue;

      if (Array.isArray((e as any).path) && (e as any).path.length) {
        for (const p of (e as any).path as [number, number][]) pts.push(p);
        continue;
      }

      const a = assetsById.get(e.from);
      const b = assetsById.get(e.to);

      if (a) pts.push([a.lat, a.lng]);
      if (b) pts.push([b.lat, b.lng]);
    }

    if (pts.length < 2) return;

    const bounds = L.latLngBounds(pts as any);
    map.fitBounds(bounds, {
      padding: [90, 90],
      maxZoom: 18,
    });
  }, [enabled, dashedEdgeIdsExtra, assetsById, map]);

  return null;
}

function FitToBarrios({
  enabled,
  barrioIds,
  includePoint,
}: {
  enabled: boolean;
  barrioIds?: Set<string>;
  includePoint?: LatLng | null;
}) {
  const map = useMap();

  React.useEffect(() => {
    if (!enabled) return;
    if (!barrioIds || barrioIds.size === 0) return;

    const pts: [number, number][] = [];

    for (const b of barrios) {
      if (!barrioIds.has(b.id)) continue;
      for (const p of b.polygon) pts.push(p);
    }

    if (includePoint) pts.push(includePoint);
    if (pts.length < 2) return;

    const bounds = L.latLngBounds(pts as any);
    map.fitBounds(bounds, {
      padding: [110, 110],
      maxZoom: 18,
    });
  }, [enabled, barrioIds, includePoint, map]);

  return null;
}

/* ---------------------------
   Crear cañería dibujando
--------------------------- */
function PipeDrawController({
  enabled,
  onCreated,
}: {
  enabled: boolean;
  onCreated: (geom: any) => void;
}) {
  const map = useMap();

  React.useEffect(() => {
    const m: any = map as any;
    if (!m?.pm) return;

    const handleCreate = (e: any) => {
      try {
        const gj = e?.layer?.toGeoJSON?.();
        const geom = gj?.geometry;
        if (geom) onCreated(geom);
      } catch {}

      try {
        map.removeLayer(e.layer);
      } catch {}
    };

    map.on("pm:create", handleCreate);

    return () => {
      map.off("pm:create", handleCreate);
    };
  }, [map, onCreated]);

  React.useEffect(() => {
    const m: any = map as any;
    if (!m?.pm) return;

    if (enabled) {
      try {
        m.pm.enableDraw("Line", {
          snappable: true,
          snapDistance: 20,
          allowSelfIntersection: false,
        });
      } catch {}
    } else {
      try {
        m.pm.disableDraw("Line");
      } catch {}
    }
  }, [map, enabled]);

  return null;
}

/* ===========================
   Helpers API nodes lite
=========================== */
type NodeLite = {
  id: string;
  kind?: string;
  label?: string;
  lat?: number;
  lng?: number;
};

async function fetchNodesLiteSafe(): Promise<NodeLite[]> {
  try {
    const items = await fetchNodes(5000);

    return items
      .map((x: any) => ({
        id: String(x?.id ?? ""),
        kind: x?.kind ? String(x.kind) : undefined,
        label: x?.label ? String(x.label) : undefined,
        lat: x?.lat != null ? Number(x.lat) : undefined,
        lng: x?.lng != null ? Number(x.lng) : undefined,
      }))
      .filter((x: NodeLite) => !!x.id);
  } catch (e: any) {
    console.warn("No se pudieron cargar nodos para conectar cañerías:", e?.message ?? e);
    return [];
  }
}

type PipeConnHint = {
  from_node: string | null;
  to_node: string | null;
  connected: boolean;
};

function normalizeConnValue(v: any): string | null {
  if (v == null) return null;

  if (typeof v === "object") {
    if (v.id != null) return normalizeConnValue(v.id);
    if (v.node_id != null) return normalizeConnValue(v.node_id);
    return null;
  }

  const s = String(v).trim();
  if (!s) return null;

  if (["null", "undefined", "none", "nan", "sin conectar", "unconnected", "-"].includes(s.toLowerCase())) {
    return null;
  }

  return s;
}

function pickFirstConn(...values: any[]) {
  for (const v of values) {
    const n = normalizeConnValue(v);
    if (n) return n;
  }

  return null;
}

function pipeConnHintFromFeature(feature: any): PipeConnHint {
  const p = feature?.properties ?? {};
  const props = p?.props ?? {};

  const from_node = pickFirstConn(
    p.from_node,
    p.fromNode,
    p.from_node_id,
    p.fromNodeId,
    p.source_node,
    p.sourceNode,
    p.source,
    p.start_node,
    p.startNode,
    p.u,
    props.from_node,
    props.fromNode,
    props.from_node_id,
    props.fromNodeId,
    props.source_node,
    props.sourceNode,
    props.source,
    props.start_node,
    props.startNode,
    props.u
  );

  const to_node = pickFirstConn(
    p.to_node,
    p.toNode,
    p.to_node_id,
    p.toNodeId,
    p.target_node,
    p.targetNode,
    p.target,
    p.end_node,
    p.endNode,
    p.v,
    props.to_node,
    props.toNode,
    props.to_node_id,
    props.toNodeId,
    props.target_node,
    props.targetNode,
    props.target,
    props.end_node,
    props.endNode,
    props.v
  );

  return {
    from_node,
    to_node,
    connected: Boolean(from_node && to_node && from_node !== to_node),
  };
}

/* ===========================
   Leyenda visual
=========================== */
function LegendDot({ color }: { color: string }) {
  return (
    <span
      style={{
        width: 10,
        height: 10,
        borderRadius: 999,
        display: "inline-block",
        background: color,
        boxShadow: "0 0 0 2px rgba(255,255,255,0.12)",
        flex: "0 0 auto",
      }}
    />
  );
}

function LegendLine({
  color,
  width,
  dash,
}: {
  color: string;
  width: number;
  dash?: boolean;
}) {
  return (
    <span
      style={{
        width: 38,
        height: 0,
        borderTop: `${width}px ${dash ? "dashed" : "solid"} ${color}`,
        borderRadius: 999,
        display: "inline-block",
        flex: "0 0 auto",
      }}
    />
  );
}

function MapLegendOverlay({
  simActive,
  showPressureNodes,
}: {
  simActive: boolean;
  showPressureNodes: boolean;
}) {
  return (
    <div
      style={{
        position: "absolute",
        left: 16,
        bottom: 18,
        zIndex: 1000,
        width: 280,
        padding: 12,
        borderRadius: 16,
        background: "rgba(15,23,42,0.82)",
        color: "#fff",
        border: "1px solid rgba(255,255,255,0.14)",
        boxShadow: "0 14px 36px rgba(0,0,0,0.35)",
        backdropFilter: "blur(9px)",
        fontSize: 12,
      }}
    >
      <div
        style={{
          fontWeight: 900,
          fontSize: 12,
          letterSpacing: 0.4,
          textTransform: "uppercase",
          marginBottom: 8,
        }}
      >
        Referencias hidráulicas
      </div>

      <div style={{ display: "grid", gap: 5 }}>
        <div style={{ fontWeight: 800, opacity: 0.8 }}>Tipo de cañería</div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <LegendLine color="#2563eb" width={4} />
          <span>Impulsión</span>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <LegendLine color="#16a34a" width={4} dash />
          <span>Distribución</span>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <LegendLine color="#14b8a6" width={3} dash />
          <span>Ramal / secundaria</span>
        </div>

        <div style={{ height: 1, background: "rgba(255,255,255,0.14)", margin: "6px 0" }} />

        <div style={{ fontWeight: 800, opacity: 0.8 }}>Diámetro</div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <LegendLine color="#dbeafe" width={2} />
          <span>Menor diámetro</span>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <LegendLine color="#dbeafe" width={7} />
          <span>Mayor diámetro</span>
        </div>

        {simActive && (
          <>
            <div style={{ height: 1, background: "rgba(255,255,255,0.14)", margin: "6px 0" }} />

            <div style={{ fontWeight: 800, opacity: 0.8 }}>
              Presión estimada {showPressureNodes ? "(puntos activos)" : ""}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 5 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#ef4444" />
                <span>&lt; 0.5 bar</span>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#f97316" />
                <span>0.5 - 1.2</span>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#facc15" />
                <span>1.2 - 2.0</span>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#22c55e" />
                <span>2.0 - 5.0</span>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#38bdf8" />
                <span>5.0 - 6.5</span>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <LegendDot color="#a855f7" />
                <span>&gt; 6.5</span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ===========================
   MapView
=========================== */
export function MapView(props: {
  zoom: number;
  setZoom: (z: number) => void;

  mode: "NONE" | "ZONE" | "ASSET";
  selectedZoneId: string | null;

  assets: Asset[];
  assetsById: Map<string, Asset>;

  valveEnabled: Record<string, boolean>;
  highlightedBarrioIds: Set<string>;
  highlightedEdgeIds: Set<string>;

  highlightedBarrioIdsExtra?: Set<string>;
  dashedEdgeIdsExtra?: Set<string>;

  onSelectZone: (z: Zone) => void;
  onSelectAsset: (id: string) => void;

  shrinkOthers: boolean;
  focusPair: FocusPair;
  focusTarget: LatLng | null;

  viewMode: ViewMode;
  viewSelectedId: string | null;
  mapGrey: boolean;

  activeValvePos?: LatLng | null;
  forceShowAssetIds?: Set<string>;
}) {
  const {
    zoom,
    setZoom,
    mode,
    selectedZoneId,
    assets,
    assetsById,
    valveEnabled,
    highlightedBarrioIds,
    highlightedBarrioIdsExtra,
    dashedEdgeIdsExtra,
    onSelectZone,
    onSelectAsset,
    shrinkOthers,
    focusPair,
    focusTarget,
    viewMode,
    viewSelectedId,
    mapGrey,
    activeValvePos,
    forceShowAssetIds,
  } = props;

  const hasRoute = (dashedEdgeIdsExtra?.size ?? 0) > 0;
  const hasBarrioImpact = (highlightedBarrioIdsExtra?.size ?? 0) > 0;

  const showZones = viewMode === "ALL" || viewMode === "ZONES";
  const showPipes = viewMode === "ALL" || viewMode === "PIPES";
  const showBarrios = viewMode === "ALL" || viewMode === "BARRIOS";

  const zonesToShow =
    viewMode === "ZONES" && viewSelectedId ? zones.filter((z) => z.id === viewSelectedId) : zones;

  const BARRIOS_MIN_ZOOM = 13.2;
  const canDrawBarrios = zoom >= BARRIOS_MIN_ZOOM || (mode === "ZONE" && selectedZoneId);

  const barriosToShow =
    mode === "ZONE" && selectedZoneId
      ? barrios.filter((b) => b.locationId === selectedZoneId)
      : barrios;

  // Pipes state
  const [selectedPipeId, setSelectedPipeId] = React.useState<string | null>(null);
  const [selectedPipeLabel, setSelectedPipeLabel] = React.useState<string | null>(null);
  const [selectedPipeLayer, setSelectedPipeLayer] = React.useState<L.Layer | null>(null);
  const [selectedPipePos, setSelectedPipePos] = React.useState<[number, number] | null>(null);
  const [selectedPipeFeature, setSelectedPipeFeature] = React.useState<any>(null);

  const [editingPipeId, setEditingPipeId] = React.useState<string | null>(null);
  const [editingGeomOpen, setEditingGeomOpen] = React.useState(false);

  // creación por dibujo
  const [creatingPipe, setCreatingPipe] = React.useState(false);

  // visual
  const [showContours, setShowContours] = React.useState(false);
  const [showPressureNodes, setShowPressureNodes] = React.useState(true);
  const [showLegend, setShowLegend] = React.useState(true);

  // SIM
  const [simMode, setSimMode] = React.useState<SimMode>("topografico");
  const [sim, setSim] = React.useState<SimRunResponse | null>(null);
  const [simBusy, setSimBusy] = React.useState(false);
  const [simErr, setSimErr] = React.useState<string | null>(null);

  // forzar recarga de pipes
  const [pipesReloadKey, setPipesReloadKey] = React.useState(0);

  // Connect drawer
  const [connectOpen, setConnectOpen] = React.useState(false);
  const [nodesLite, setNodesLite] = React.useState<NodeLite[]>([]);
  const [nodesBusy, setNodesBusy] = React.useState(false);
  const [pipeConnectivityStats, setPipeConnectivityStats] = React.useState<PipeConnectivityStats | null>(null);

  const connHint = React.useMemo(() => pipeConnHintFromFeature(selectedPipeFeature), [selectedPipeFeature]);

  function clearPipeSelection() {
    setSelectedPipeId(null);
    setSelectedPipeLabel(null);
    setSelectedPipeLayer(null);
    setSelectedPipePos(null);
    setSelectedPipeFeature(null);
    setEditingPipeId(null);
    setEditingGeomOpen(false);
    setConnectOpen(false);
  }

  async function ensureNodes() {
    if (nodesBusy) return;

    setNodesBusy(true);

    try {
      const items = await fetchNodesLiteSafe();
      setNodesLite(items);
    } finally {
      setNodesBusy(false);
    }
  }

  async function runSimulation(modeToRun: SimMode = simMode) {
    setSimBusy(true);
    setSimErr(null);

    try {
      const r = await runSim({
        default_diam_mm: 75,
        r_scale: 1,
        head_drop_scale: modeToRun === "topografico" ? 0 : 0.0000001,
        ignore_unconnected: true,
        closed_valve_blocks_node: true,
        min_pressure_m: 0,
      });

      setSim(r as any);
    } catch (e: any) {
      setSimErr(e?.message ?? "No se pudo simular");
    } finally {
      setSimBusy(false);
    }
  }

  function toggleSimMode() {
    const next: SimMode = simMode === "topografico" ? "hidraulico_suave" : "topografico";
    setSimMode(next);

    if (sim) {
      runSimulation(next);
    }
  }

  return (
    <>
      <div style={{ position: "relative", width: "100%", height: "100%" }}>
        {/* Controles flotantes */}
        <div
          style={{
            position: "absolute",
            right: 16,
            top: 16,
            zIndex: 1000,
            display: "grid",
            gap: 8,
            width: 170,
          }}
        >
          <button
            onClick={() => setCreatingPipe((v) => !v)}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: creatingPipe ? "rgba(37,99,235,0.95)" : "rgba(15,23,42,0.78)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
            }}
          >
            {creatingPipe ? "Cancelar dibujo" : "+ Cañería"}
          </button>

          <button
            onClick={() => setShowContours((v) => !v)}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: showContours ? "rgba(14,165,233,0.95)" : "rgba(15,23,42,0.78)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
            }}
            title="Mostrar curvas de nivel / topografía"
          >
            {showContours ? "Curvas: ON" : "Curvas"}
          </button>

          <button
            onClick={() => setShowPressureNodes((v) => !v)}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: showPressureNodes ? "rgba(20,184,166,0.95)" : "rgba(15,23,42,0.78)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
              opacity: sim ? 1 : 0.72,
            }}
            title="Mostrar puntos de presión al simular"
          >
            {showPressureNodes ? "Puntos: ON" : "Puntos"}
          </button>

          <button
            onClick={toggleSimMode}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: simMode === "topografico" ? "rgba(99,102,241,0.95)" : "rgba(217,119,6,0.95)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
            }}
            title="Cambiar modo de simulación"
          >
            {simMode === "topografico" ? "Modo: Topo" : "Modo: Hidr."}
          </button>

          <button
            onClick={() => {
              if (sim) setSim(null);
              else runSimulation();
            }}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: sim ? "rgba(34,197,94,0.95)" : "rgba(15,23,42,0.78)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
            }}
            title={sim ? "Quitar simulación" : "Correr simulación"}
          >
            {simBusy ? "Simulando..." : sim ? "SIM: ON" : "SIM"}
          </button>

          <button
            onClick={() => setShowLegend((v) => !v)}
            style={{
              padding: "8px 10px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.2)",
              background: showLegend ? "rgba(15,23,42,0.78)" : "rgba(15,23,42,0.5)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              fontSize: 12,
              boxShadow: "0 12px 25px rgba(0,0,0,0.22)",
            }}
          >
            {showLegend ? "Ocultar leyenda" : "Ver leyenda"}
          </button>
        </div>

        {simErr && (
          <div
            style={{
              position: "absolute",
              right: 16,
              top: 318,
              zIndex: 1000,
              background: "rgba(220,38,38,0.92)",
              color: "#fff",
              padding: "8px 10px",
              borderRadius: 10,
              maxWidth: 360,
              fontSize: 12,
              fontWeight: 700,
            }}
          >
            {simErr}
          </div>
        )}

        {showPipes && pipeConnectivityStats && (
          <div className="pipeConnOverlay" style={{ top: simErr ? 365 : 318 }}>
            <div className="pipeConnOverlay__title">
              {sim ? "Cañerías simuladas" : "Conectividad de cañerías"}
            </div>

            <div className="pipeConnOverlay__row">
              <span className="pipeConnOverlay__dot pipeConnOverlay__dot--ok" />
              <span>{pipeConnectivityStats.connected} conectadas</span>
            </div>

            <div className="pipeConnOverlay__row">
              <span className="pipeConnOverlay__dot pipeConnOverlay__dot--warn" />
              <span>{pipeConnectivityStats.unconnected} sin conectar</span>
            </div>
          </div>
        )}

        {showLegend && <MapLegendOverlay simActive={!!sim} showPressureNodes={showPressureNodes} />}

        <MapContainer
          className={mapGrey ? "mapGrey" : undefined}
          center={CENTER}
          zoom={13.8}
          minZoom={11}
          maxZoom={22}
          zoomControl={false}
          style={{ height: "100%", width: "100%" }}
        >
          <ZoomWatcher onZoom={setZoom} />
          <ZoomControl position="bottomright" />

          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxZoom={22}
            maxNativeZoom={19}
          />

          {/* Capa visual de curvas/topografía */}
          <ContourVisualLayer visible={showContours} opacity={0.68} />

          {/* mientras haya un modal abierto, NO limpiamos por click en mapa */}
          <MapClickClear onClear={clearPipeSelection} enabled={!editingPipeId && !editingGeomOpen && !connectOpen} />

          {/* Crear cañería */}
          <PipeDrawController
            enabled={creatingPipe}
            onCreated={async (geom) => {
              try {
                await createPipe({
                  geometry: geom,
                  properties: {
                    type: "WATER",
                    estado: "OK",
                    flow_func: "DISTRIBUCION",
                    diametro_mm: null,
                    material: null,
                    props: { Layer: "Nueva cañería" },
                    style: {},
                  },
                });

                setCreatingPipe(false);
                setPipesReloadKey((k) => k + 1);
              } catch (e: any) {
                alert(e?.message ?? "No se pudo crear");
                setCreatingPipe(false);
              }
            }}
          />

          {/* Cañerías */}
          {showPipes && (
            <PipesLayer
              key={pipesReloadKey}
              visible={showPipes}
              selectedId={selectedPipeId}
              freeze={editingGeomOpen}
              sim={sim}
              showOnlySimulated={!!sim}
              onConnectivityStats={setPipeConnectivityStats}
              onSelect={(id, layer, label, feature) => {
                setSelectedPipeId(id);
                setSelectedPipeLabel(label ?? null);
                setSelectedPipeLayer(layer);
                setSelectedPipeFeature(feature ?? null);

                setEditingPipeId(null);
                setEditingGeomOpen(false);

                try {
                  const anyLayer: any = layer as any;
                  const center = anyLayer?.getBounds?.().getCenter?.() ?? anyLayer?.getLatLng?.();

                  if (center && typeof center.lat === "number" && typeof center.lng === "number") {
                    setSelectedPipePos([center.lat, center.lng]);
                  } else {
                    setSelectedPipePos(null);
                  }
                } catch {
                  setSelectedPipePos(null);
                }
              }}
            />
          )}

          {/* Puntitos de presión */}
          {sim && showPressureNodes && <PressureNodesLayer sim={sim} visible={true} />}

          {/* Popup de cañería */}
          {selectedPipeId && selectedPipePos && !editingPipeId && !editingGeomOpen && !connectOpen && (
            <Popup position={selectedPipePos} className="pipe-popup" closeButton={true} autoClose={false}>
              <div className="pipePopup">
                <div className="pipePopup__title" title={selectedPipeLabel ?? ""}>
                  {selectedPipeLabel ?? "Cañería"}
                </div>

                <div className="pipePopup__statusRow">
                  <span
                    className={
                      connHint.connected
                        ? "pipePopup__badge pipePopup__badge--ok"
                        : "pipePopup__badge pipePopup__badge--warn"
                    }
                  >
                    {connHint.connected ? "Conectada" : "Sin conectar"}
                  </span>

                  {connHint.connected ? (
                    <span className="pipePopup__connText">
                      {connHint.from_node?.slice(0, 8)} → {connHint.to_node?.slice(0, 8)}
                    </span>
                  ) : (
                    <span className="pipePopup__connText">Falta origen/destino</span>
                  )}
                </div>

                <div className="pipePopup__actions">
                  <button
                    className="pipePopup__btn pipePopup__btn--primary"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setSelectedPipePos(null);
                      setEditingGeomOpen(false);
                      setEditingPipeId(selectedPipeId);
                    }}
                  >
                    Editar
                  </button>

                  <button
                    className="pipePopup__btn"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setSelectedPipePos(null);
                      setEditingPipeId(null);
                      setEditingGeomOpen(true);
                    }}
                  >
                    Recorrido
                  </button>

                  <button
                    className="pipePopup__btn"
                    onClick={async (e) => {
                      e.preventDefault();
                      e.stopPropagation();

                      if (!selectedPipeId) return;

                      if (sim) {
                        alert("Apagá la simulación para conectar manualmente cañerías.");
                        return;
                      }

                      await ensureNodes();
                      setConnectOpen(true);
                    }}
                    title={nodesBusy ? "Cargando nodos..." : connHint.connected ? "Modificar conexión" : "Conectar a nodos"}
                  >
                    {nodesBusy ? "Nodos..." : connHint.connected ? "Conexión" : "Conectar"}
                  </button>

                  <button
                    className="pipePopup__btn"
                    onClick={async (e) => {
                      e.preventDefault();
                      e.stopPropagation();

                      if (!selectedPipeId) return;

                      const ok = confirm(`¿Borrar cañería "${selectedPipeLabel ?? ""}"?`);
                      if (!ok) return;

                      try {
                        await deletePipe(selectedPipeId);
                        clearPipeSelection();
                        setPipesReloadKey((k) => k + 1);
                      } catch (err: any) {
                        alert(err?.message ?? "No se pudo borrar");
                      }
                    }}
                  >
                    Borrar
                  </button>

                  <button
                    className="pipePopup__btn"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      clearPipeSelection();
                    }}
                  >
                    Cerrar
                  </button>
                </div>

                {sim?.pipes?.[selectedPipeId] && (
                  <div style={{ marginTop: 10, fontSize: 12, opacity: 0.9 }}>
                    <div>
                      <b>Q visual</b>: {Number(sim.pipes[selectedPipeId].q_lps ?? 0).toFixed(3)} L/s{" "}
                      ({sim.pipes[selectedPipeId].dir === 1 ? "from→to" : "to→from"})
                    </div>

                    <div>
                      <b>ΔH</b>:{" "}
                      {sim.pipes[selectedPipeId].dH_m == null
                        ? "N/D"
                        : Number(sim.pipes[selectedPipeId].dH_m).toFixed(2)}{" "}
                      m
                    </div>

                    {sim.pipes[selectedPipeId].blocked && (
                      <div style={{ fontWeight: 800, color: "#b91c1c" }}>BLOQUEADO</div>
                    )}
                  </div>
                )}
              </div>
            </Popup>
          )}

          {/* Zonas */}
          {showZones &&
            zonesToShow.map((z) => {
              const sel = mode === "ZONE" && selectedZoneId === z.id;
              const c = centroid(z.polygon);

              const icon = (() => {
                if (sel) return locationMarkerIcon(z.name, true, 1, 1);
                return locationMarkerIcon(z.name, false, 0.78, 0.55);
              })();

              const showPolygon = sel || zoom >= 15;

              return (
                <React.Fragment key={z.id}>
                  <Marker position={c} icon={icon} eventHandlers={{ click: () => onSelectZone(z) }} />

                  {showPolygon && (
                    <Polygon
                      positions={z.polygon}
                      pathOptions={{
                        color: "rgba(255,255,255,0.35)",
                        weight: sel ? 3 : 1.5,
                        fillOpacity: sel ? 0.07 : 0.03,
                        dashArray: sel ? undefined : "8 12",
                        lineCap: "round",
                        lineJoin: "round",
                      }}
                      eventHandlers={{ click: () => onSelectZone(z) }}
                    />
                  )}
                </React.Fragment>
              );
            })}

          {/* Barrios */}
          {showBarrios &&
            canDrawBarrios &&
            barriosToShow.map((b) => {
              const hlBase = highlightedBarrioIds.has(b.id);
              const hlByValve = highlightedBarrioIdsExtra?.has(b.id) ?? false;
              const hl = hlBase || hlByValve;

              const pres = pressureLabelForBarrio(b);

              return (
                <Polygon
                  key={b.id}
                  positions={b.polygon}
                  pathOptions={{
                    color: hl ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.55)",
                    fillColor: hl ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.15)",
                    fillOpacity: hl ? 0.45 : 0.3,
                    weight: hl ? 4 : 2,
                  }}
                >
                  <Tooltip sticky direction="top" opacity={0.98}>
                    <div style={{ fontWeight: 900 }}>{b.name}</div>
                    <div style={{ fontSize: 12 }}>{pres.label}</div>
                  </Tooltip>
                </Polygon>
              );
            })}

          <FitToRoute enabled={hasRoute} dashedEdgeIdsExtra={dashedEdgeIdsExtra} assetsById={assetsById} />

          {!hasRoute && (
            <FitToBarrios
              enabled={hasBarrioImpact}
              barrioIds={highlightedBarrioIdsExtra}
              includePoint={activeValvePos ?? null}
            />
          )}

          {!hasRoute && !hasBarrioImpact && <FlyTo target={focusTarget} />}

          {focusPair && (
            <>
              <Marker interactive={false} position={focusPair.a.pos} icon={focusPointIcon(focusPair.a.label)} />
              <Marker interactive={false} position={focusPair.b.pos} icon={focusPointIcon(focusPair.b.label)} />
            </>
          )}
        </MapContainer>
      </div>

      {/* Drawer conectar pipe */}
      <PipeConnectDrawer
        open={connectOpen}
        onClose={() => setConnectOpen(false)}
        pipeId={selectedPipeId}
        pipeFeature={selectedPipeFeature}
        nodes={nodesLite}
        initialFrom={connHint.from_node}
        initialTo={connHint.to_node}
        onConnected={(from, to) => {
          setSelectedPipeFeature((prev: any) => {
            if (!prev) return prev;

            return {
              ...prev,
              properties: {
                ...(prev.properties ?? {}),
                from_node: from,
                to_node: to,
                connected: true,
              },
            };
          });

          setPipesReloadKey((k) => k + 1);
        }}
      />

      {/* Editor recorrido */}
      <PipeGeometryEditor
        open={editingGeomOpen}
        pipeId={selectedPipeId}
        pipeLayer={selectedPipeLayer}
        onClose={() => setEditingGeomOpen(false)}
        onSaved={() => {
          setPipesReloadKey((k) => k + 1);
          if (sim) runSimulation();
        }}
      />

      {/* Editor propiedades */}
      <PipeEditDrawer
        pipeId={editingPipeId}
        onClose={() => setEditingPipeId(null)}
        onUpdated={(feature) => {
          const nextLabel = feature?.properties?.props?.Layer ?? feature?.properties?.props?.layer ?? null;

          if (nextLabel != null) setSelectedPipeLabel(String(nextLabel));

          setPipesReloadKey((k) => k + 1);

          if (sim) runSimulation();
        }}
      />
    </>
  );
}