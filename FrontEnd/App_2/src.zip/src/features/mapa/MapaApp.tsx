// src/features/mapa/MapaApp.tsx
import "./src/styles.css"; // si tu mapa tiene styles.css (si no existe, borrá esta línea)
export { default } from "./src/MapaApp";