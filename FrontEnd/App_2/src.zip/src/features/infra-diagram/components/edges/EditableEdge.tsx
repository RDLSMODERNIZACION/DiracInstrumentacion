// src/features/infra-diagram/components/edges/EditableEdge.tsx
import React, { useMemo } from "react";
import type { UINode, PortId } from "../../types";

type Props = {
  id: number;
  a: string;
  b: string;

  // ✅ NUEVO: puertos elegidos (si no vienen, usamos fallback automático)
  a_port?: PortId;
  b_port?: PortId;

  nodesById: Record<string, UINode>;
  editable: boolean;
  selected?: boolean;
  onSelect?: (edgeId: number) => void;
};

type Side = "in" | "out";

function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

/**
 * Puertos “por defecto” por tipo (fallback si NO hay a_port/b_port).
 * - Pump: IN izquierda / OUT derecha (un poco afuera para que se vea enchufado)
 * - Tank/Manifold: extremos izquierda/derecha
 * - Valve: extremos
 */
function getDefaultPort(n: UINode, side: Side) {
  const t = (n.type || "").toLowerCase();

  // Default: centro
  let x = n.x;
  let y = n.y;

  if (t === "pump") {
    const rOuter = 26;
    const portOffset = 4;
    x = side === "in" ? n.x - rOuter - portOffset : n.x + rOuter + portOffset;
    y = n.y;
    return { x, y };
  }

  if (t === "tank") {
    const halfW = 66;
    x = side === "in" ? n.x - halfW : n.x + halfW;
    y = n.y;
    return { x, y };
  }

  if (t === "manifold") {
    const halfW = 55;
    x = side === "in" ? n.x - halfW : n.x + halfW;
    y = n.y;
    return { x, y };
  }

  if (t === "valve") {
    const half = 14;
    x = side === "in" ? n.x - half : n.x + half;
    y = n.y;
    return { x, y };
  }

  return { x, y };
}

/**
 * Coordenadas del puerto seleccionado para el nodo.
 * Si no viene portId -> fallback a getDefaultPort().
 *
 * IMPORTANTÍSIMO:
 * - Estos offsets deben coincidir con el dibujo real de cada nodo.
 * - Para Tank usamos W=132, H=100 (los del TankNodeView).
 * - Para Manifold/Valve usamos aproximación (ajustable después).
 */
function getPortPos(n: UINode, side: Side, portId?: PortId) {
  if (!portId) return getDefaultPort(n, side);

  // ---- TANK ----
  if (n.type === "tank") {
    // Debe coincidir con TankNodeView: W=132, H=100
    const W = 132;
    const H = 100;
    const P = 12;

    const leftX = n.x - W / 2;
    const rightX = n.x + W / 2;
    const topY = n.y - H / 2 + (P + 12);
    const midY = n.y;
    const botY = n.y + H / 2 - (P + 12);

    switch (portId) {
      case "L1":
        return { x: leftX, y: midY };
      case "L2":
        return { x: leftX, y: botY };
      case "R1":
        return { x: rightX, y: topY };
      case "R2":
        return { x: rightX, y: midY };
      case "R3":
        return { x: rightX, y: botY };
      case "T1":
        return { x: n.x, y: n.y - H / 2 };
      case "B1":
        return { x: n.x, y: n.y + H / 2 };
      default:
        return getDefaultPort(n, side);
    }
  }

  // ---- PUMP ----
  if (n.type === "pump") {
    const rOuter = 26;
    const portOffset = 4;
    if (portId.startsWith("L")) return { x: n.x - rOuter - portOffset, y: n.y };
    if (portId.startsWith("R")) return { x: n.x + rOuter + portOffset, y: n.y };
    return getDefaultPort(n, side);
  }

  // ---- MANIFOLD ----
  if (n.type === "manifold") {
    // Debe coincidir con tu ManifoldNodeView real. Hoy venimos usando W/2=55 (aprox).
    const halfW = 55;
    const topY = n.y - 14;
    const midY = n.y;
    const botY = n.y + 14;

    const leftX = n.x - halfW;
    const rightX = n.x + halfW;

    switch (portId) {
      case "L1":
        return { x: leftX, y: topY };
      case "L2":
        return { x: leftX, y: botY };
      case "R1":
        return { x: rightX, y: topY };
      case "R2":
        return { x: rightX, y: midY };
      case "R3":
        return { x: rightX, y: botY };
      case "T1":
        return { x: n.x, y: n.y - 22 };
      case "B1":
        return { x: n.x, y: n.y + 22 };
      default:
        return getDefaultPort(n, side);
    }
  }

  // ---- VALVE ----
  if (n.type === "valve") {
    // Válvula chica: conectamos en extremos, con posibilidad de T/B
    const half = 14;
    const leftX = n.x - half;
    const rightX = n.x + half;

    switch (portId) {
      case "L1":
      case "L2":
        return { x: leftX, y: n.y };
      case "R1":
      case "R2":
      case "R3":
        return { x: rightX, y: n.y };
      case "T1":
        return { x: n.x, y: n.y - half };
      case "B1":
        return { x: n.x, y: n.y + half };
      default:
        return getDefaultPort(n, side);
    }
  }

  return getDefaultPort(n, side);
}

/**
 * Path ortogonal con codos redondeados, usando puertos seleccionables.
 * Guarda sx/sy y ex/ey para dibujar acoples en las puntas.
 */
function pipePath(A: UINode, B: UINode, aPort?: PortId, bPort?: PortId) {
  const S = getPortPos(A, "out", aPort);
  const E = getPortPos(B, "in", bPort);

  const sx = S.x;
  const sy = S.y;
  const ex = E.x;
  const ey = E.y;

  const dx = Math.abs(ex - sx);
  const dy = Math.abs(ey - sy);

  // si casi alineado: línea recta
  if (dy < 2) {
    return { sx, sy, ex, ey, d: `M ${sx} ${sy} L ${ex} ${ey}` };
  }

  const mx = (sx + ex) / 2;

  // radio de codo dinámico
  const r = clamp(Math.min(dx, dy) / 4, 6, 14);
  const signY = ey > sy ? 1 : -1;
  const signX = ex > mx ? 1 : -1;

  const d = [
    `M ${sx} ${sy}`,
    `L ${mx - r} ${sy}`,
    `Q ${mx} ${sy} ${mx} ${sy + signY * r}`,
    `L ${mx} ${ey - signY * r}`,
    `Q ${mx} ${ey} ${mx + signX * r} ${ey}`,
    `L ${ex} ${ey}`,
  ].join(" ");

  return { sx, sy, ex, ey, d };
}

export default function EditableEdge({
  id,
  a,
  b,
  a_port,
  b_port,
  nodesById,
  editable,
  selected,
  onSelect,
}: Props) {
  const A = nodesById[a];
  const B = nodesById[b];

  const geom = useMemo(() => (A && B ? pipePath(A, B, a_port, b_port) : null), [A, B, a_port, b_port]);
  if (!A || !B || !geom) return null;

  // Estética “tubería”
  const STROKE_OUTER = 10; // sombra/borde
  const STROKE_BODY = 7; // cuerpo
  const STROKE_HL = 2.2; // brillo
  const HIT_STROKE = 18; // área clic

  // Acoples (bridas/niples) en los extremos
  const COUPLER_R_OUT = 3.6;
  const COUPLER_R_IN = 2.2;

  return (
    <g>
      {/* ===== TUBERÍA (3 capas) ===== */}

      {/* sombra exterior */}
      <path
        d={geom.d}
        fill="none"
        stroke="#0f172a"
        strokeWidth={STROKE_OUTER}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={0.55}
      />

      {/* cuerpo */}
      <path
        d={geom.d}
        fill="none"
        stroke="#cbd5e1"
        strokeWidth={STROKE_BODY}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={0.95}
      />

      {/* brillo */}
      <path
        d={geom.d}
        fill="none"
        stroke="rgba(255,255,255,0.45)"
        strokeWidth={STROKE_HL}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={0.9}
      />

      {/* ===== ACOPLES (para que se vea “enchufado”) ===== */}
      <circle cx={geom.sx} cy={geom.sy} r={COUPLER_R_OUT} fill="#0f172a" opacity={0.35} />
      <circle cx={geom.sx} cy={geom.sy} r={COUPLER_R_IN} fill="#e2e8f0" opacity={0.98} />

      <circle cx={geom.ex} cy={geom.ey} r={COUPLER_R_OUT} fill="#0f172a" opacity={0.35} />
      <circle cx={geom.ex} cy={geom.ey} r={COUPLER_R_IN} fill="#e2e8f0" opacity={0.98} />

      {/* ===== HIT TEST (invisible, para click) ===== */}
      <path
        d={geom.d}
        stroke="transparent"
        strokeWidth={HIT_STROKE}
        fill="none"
        style={{ pointerEvents: "stroke", cursor: editable ? "pointer" : "default" }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect?.(id);
        }}
      />

      {/* ===== SELECCIÓN (halo + línea) ===== */}
      {selected && (
        <>
          <path
            d={geom.d}
            fill="none"
            stroke="#38bdf8"
            strokeWidth={STROKE_OUTER + 2}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={0.22}
          />
          <path
            d={geom.d}
            fill="none"
            stroke="#0ea5e9"
            strokeWidth={3.5}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={0.95}
          />
        </>
      )}
    </g>
  );
}
