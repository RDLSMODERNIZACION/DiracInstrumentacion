import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MapaApp from "../features/mapa/MapaApp";
import "../features/mapa/styles.css"; // trae tus variables/estilos del mapa

export default function MapaPage() {
  const navigate = useNavigate();

  // opcional: arregla íconos leaflet (si tu MapaApp no lo hace ya)
  useEffect(() => {}, []);

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <div style={{ padding: 8, display: "flex", gap: 8, alignItems: "center" }}>
        <button
          onClick={() => navigate("/")}
          style={{
            padding: "4px 8px",
            borderRadius: 8,
            border: "1px solid #cbd5e1",
            background: "#fff",
          }}
        >
          ← Volver
        </button>
      </div>

      <div style={{ width: "100%", height: "calc(100vh - 48px)" }}>
        <MapaApp />
      </div>
    </div>
  );
}
