import InfraDiagram from "@/features/infra-diagram/InfraDiagram";

export default function App() {
  return <InfraDiagram />;
}
