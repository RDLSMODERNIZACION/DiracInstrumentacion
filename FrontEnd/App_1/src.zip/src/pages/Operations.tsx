import React from "react";
import Widget from "@/widget";

export default function Operations() {
  return <Widget />;
}
