import { useEffect, useMemo, useState } from "react";
import { fetchPumpsLive, fetchTanksLive } from "@/api/graphs";
import { TZ, H, startOfMin, floorToMinuteISO, buildHourTicks, fmtDayTime } from "../helpers/time";

type TsTank = { timestamps: number[]; level_percent: (number | null)[] } | null;
type TsPump = { timestamps: number[]; is_on: (number | null)[] } | null;

export function usePlayback({
  tab,
  locId,
  liveWindow,
  liveTankTs,
  livePumpTs,
  selectedPumpIds,
  selectedTankIds,
}: {
  tab: string;
  locId?: number;
  liveWindow?: { start: number; end: number } | null;
  liveTankTs?: TsTank | any;
  livePumpTs?: TsPump | any;
  selectedPumpIds: number[] | "all";
  selectedTankIds: number[] | "all";
}) {
  const MAX_OFFSET_MIN = 7 * 24 * 60;
  const MIN_OFFSET_MIN = 24 * 60;

  const [playEnabled, setPlayEnabled] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [playFinMin, setPlayFinMin] = useState(MAX_OFFSET_MIN);
  const [dragging, setDragging] = useState(false);
  const [finDebounced, setFinDebounced] = useState(MAX_OFFSET_MIN);

  const [playTankTs, setPlayTankTs] = useState<TsTank>(null);
  const [playPumpTs, setPlayPumpTs] = useState<TsPump>(null);
  const [loadingPlay, setLoadingPlay] = useState(false);

  const baseStartMs = useMemo(() => startOfMin(Date.now() - 7 * 24 * H), []);

  const xDomainLive = useMemo(() => {
    const win = liveWindow;
    if (win?.start && win?.end) return [win.start, win.end] as [number, number];
    const end = startOfMin(Date.now());
    const start = end - 24 * H;
    return [start, end] as [number, number];
  }, [liveWindow]);

  const sliderDomain: [number, number] = useMemo(() => {
    const to = baseStartMs + playFinMin * 60_000;
    const from = to - 24 * H;
    return [from, to];
  }, [baseStartMs, playFinMin]);

  const domain = playEnabled ? sliderDomain : xDomainLive;
  const ticks = useMemo(() => buildHourTicks(domain), [domain[0], domain[1]]);

  const startLabel = useMemo(() => fmtDayTime(domain[0], TZ), [domain]);
  const endLabel = useMemo(() => fmtDayTime(domain[1], TZ), [domain]);

  // Debounce over slider
  useEffect(() => {
    if (!playEnabled || !locId) return;
    if (dragging) return;
    const id = window.setTimeout(() => setFinDebounced(playFinMin), 600);
    return () => window.clearTimeout(id);
  }, [playEnabled, dragging, playFinMin, locId]);

  // Fetch playback 24h
  useEffect(() => {
    if (!playEnabled || !locId) {
      setPlayTankTs(null);
      setPlayPumpTs(null);
      return;
    }
    let cancelled = false;
    const toMs = startOfMin(baseStartMs + finDebounced * 60_000);
    const fromMs = toMs - 24 * H;
    const fromISO = floorToMinuteISO(new Date(fromMs));
    const toISO = floorToMinuteISO(new Date(toMs));
    setLoadingPlay(true);
    (async () => {
      try {
        const [pumps, tanks] = await Promise.all([
          fetchPumpsLive({
            from: fromISO,
            to: toISO,
            locationId: locId,
            pumpIds: selectedPumpIds === "all" ? undefined : selectedPumpIds,
            bucket: "1min",
            aggMode: "avg",
            connectedOnly: true,
          }),
          fetchTanksLive({
            from: fromISO,
            to: toISO,
            locationId: locId,
            tankIds: selectedTankIds === "all" ? undefined : selectedTankIds,
            agg: "avg",
            carry: true,
            bucket: "1min",
            connectedOnly: true,
          }),
        ]);
        if (cancelled) return;
        setPlayPumpTs({ timestamps: pumps.timestamps, is_on: pumps.is_on });
        setPlayTankTs({ timestamps: tanks.timestamps, level_percent: tanks.level_percent });
      } catch (e) {
        if (!cancelled) {
          setPlayPumpTs(null);
          setPlayTankTs(null);
        }
        console.error("[playback] fetch error:", e);
      } finally {
        if (!cancelled) setLoadingPlay(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [playEnabled, finDebounced, locId, selectedPumpIds, selectedTankIds, baseStartMs]);

  // Auto-play avanza 10 min/seg
  useEffect(() => {
    if (!playEnabled || !playing) return;
    const id = window.setInterval(() => {
      setPlayFinMin((prev) => Math.min(MAX_OFFSET_MIN, prev + 10));
    }, 1000);
    return () => window.clearInterval(id);
  }, [playEnabled, playing]);

  const tankTs = playEnabled && playTankTs ? playTankTs : (liveTankTs ?? { timestamps: [], level_percent: [] });
  const pumpTs = playEnabled && playPumpTs ? playPumpTs : (livePumpTs ?? { timestamps: [], is_on: [] });

  return {
    // state
    playEnabled,
    setPlayEnabled,
    playing,
    setPlaying,
    playFinMin,
    setPlayFinMin,
    MIN_OFFSET_MIN,
    MAX_OFFSET_MIN,
    dragging,
    setDragging,
    // view
    domain,
    ticks,
    startLabel,
    endLabel,
    // series
    tankTs,
    pumpTs,
    // flags
    loadingPlay,
  };
}
