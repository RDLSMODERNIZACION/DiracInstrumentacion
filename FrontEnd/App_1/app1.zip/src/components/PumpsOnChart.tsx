// src/components/PumpsOnChart.tsx
import React, { useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  ResponsiveContainer,
  BarChart,
  XAxis,
  YAxis,
  Tooltip,
  Bar,
} from "recharts";

/** Serie agregada del hook: timestamps (ms/ISO) + cantidad ON */
type Agg = { timestamps?: Array<number | string>; is_on?: Array<number | boolean | string | null> };

type Props = {
  pumpsTs: Agg | null | undefined;
  title?: string;
  tz?: string;           // default "America/Argentina/Buenos_Aires"
  height?: number;       // default 224
  max?: number;          // escala Y superior opcional
  syncId?: string;       // ej: "op-sync"
};

// ================== helpers ==================
const toMs = (x: number | string) => {
  if (typeof x === "number") return x > 10_000 ? x : x * 1000;
  const n = Number(x);
  if (Number.isFinite(n) && n > 10_000) return n;
  return new Date(x).getTime();
};
const startOfMin  = (ms: number) => { const d = new Date(ms); d.setSeconds(0,0); return d.getTime(); };
const startOfHour = (ms: number) => { const d = new Date(ms); d.setMinutes(0,0,0); return d.getTime(); };
const addMinutes  = (ms: number, m: number) => ms + m * 60_000;
const addHours    = (ms: number, h: number) => ms + h * 3_600_000;

const fmtHour = (ms: number, tz = "America/Argentina/Buenos_Aires") => {
  try {
    return new Intl.DateTimeFormat("es-AR", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(ms);
  } catch {
    const d = new Date(ms); const hh = String(d.getHours()).padStart(2,"0"); const mm = String(d.getMinutes()).padStart(2,"0");
    return `${hh}:${mm}`;
  }
};

function buildMinuteGrid24h(pumps: Agg) {
  const ts = pumps?.timestamps ?? [];
  const vs = pumps?.is_on ?? [];
  const pairs: Array<{ ms: number; on: number }> = [];

  const N = Math.min(ts.length, vs.length);
  for (let i = 0; i < N; i++) {
    const ms = toMs(ts[i] as any);
    if (!Number.isFinite(ms)) continue;
    let on = vs[i];
    on = typeof on === "boolean" ? (on ? 1 : 0) : (on == null ? 0 : Number(on));
    if (!Number.isFinite(on as number)) on = 0;
    pairs.push({ ms, on: on as number });
  }

  const last = pairs.length ? Math.max(...pairs.map(p => p.ms)) : Date.now();
  const end   = startOfMin(last);
  const start = addHours(end, -24);

  // minuto → max ON en ese minuto
  const perMin = new Map<number, number>();
  for (const p of pairs) {
    if (p.ms < start || p.ms > end) continue;
    const m = startOfMin(p.ms);
    const cur = perMin.get(m) ?? 0;
    if (p.on > cur) perMin.set(m, p.on);
  }

  // serie numérica (ms) para sincronizar por valor con tanques
  const series: Array<{ x: number; on: number | null }> = [];
  for (let t = start; t <= end; t = addMinutes(t, 1)) {
    const on = perMin.get(t) ?? 0;
    series.push({ x: t, on: on > 0 ? on : null }); // null = NO dibuja barra
  }

  // ticks de cada hora (HH:00)
  const ticks: number[] = [];
  for (let t = startOfHour(start); t <= end; t = addHours(t, 1)) ticks.push(t);

  const yDataMax = Math.max(0, ...series.map(d => d.on ?? 0));
  return { series, ticks, yDataMax };
}

// ================== component ==================
export default function PumpsOnChart({
  pumpsTs,
  title = "Bombas encendidas (24h • en vivo)",
  tz = "America/Argentina/Buenos_Aires",
  height = 224,
  max,
  syncId,
}: Props) {
  const { series, ticks, yDataMax } = useMemo(() => buildMinuteGrid24h(pumpsTs ?? {}), [pumpsTs]);
  const hasAnyBar = series.some(d => d.on != null);
  const yMax = Math.max(1, yDataMax, max ?? 0);

  // 🎨 estética
  const AXIS_COLOR = "rgba(0,0,0,.20)";
  const TICK_COLOR = "#475569"; // slate-600
  const BAR_PX = 8;             // ⬅️ barras más anchas
  const BAR_RADIUS: [number, number, number, number] = [6, 6, 0, 0]; // puntas redondeadas

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm text-gray-500">{title}</CardTitle>
      </CardHeader>

      <CardContent style={{ height }}>
        {!hasAnyBar ? (
          <div className="h-full grid place-items-center text-sm text-gray-500">Sin eventos ON en las últimas 24 h.</div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={series}
              syncId={syncId}
              syncMethod="value"
              margin={{ top: 10, right: 10, left: 10, bottom: 6 }}
              barCategoryGap={0}
              barGap={0}
            >
              {/* Eje X minimal, igual que eficiencia: solo HH:mm en horas */}
              <XAxis
                dataKey="x"
                type="number"
                scale="time"
                domain={["dataMin", "dataMax"]}
                ticks={ticks}
                tickFormatter={(v) => fmtHour(v as number, tz)}
                axisLine={{ stroke: AXIS_COLOR }}
                tickLine={false}
                tick={{ fontSize: 11, fill: TICK_COLOR }}
                minTickGap={24}
              />

              {/* Eje Y simple, sin grilla */}
              <YAxis
                domain={[0, yMax]}
                allowDecimals={false}
                width={28}
                axisLine={{ stroke: AXIS_COLOR }}
                tickLine={false}
                tick={{ fontSize: 11, fill: TICK_COLOR }}
              />

              {/* Tooltip limpio */}
              <Tooltip
                cursor={{ fillOpacity: 0 }}
                content={({ active, payload }) => {
                  if (!active || !payload || !payload.length) return null;
                  const p = payload[0].payload as { x: number; on: number | null };
                  return (
                    <div className="rounded-md border bg-white/95 px-2 py-1 text-xs shadow">
                      <div>{fmtHour(p.x, tz)} h</div>
                      <div><strong>{p.on ?? 0}</strong> ON</div>
                    </div>
                  );
                }}
              />

              {/* Barras: negras, anchas y con borde redondeado arriba */}
              <Bar
                dataKey="on"
                isAnimationActive={false}
                fill="#000"
                stroke="#000"
                barSize={BAR_PX}
                maxBarSize={BAR_PX}
                radius={BAR_RADIUS}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}
