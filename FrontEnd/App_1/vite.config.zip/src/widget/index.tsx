import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { KPI } from "@/components/KPI";
import TankLevelChart from "@/components/TankLevelChart";
import OpsPumpsProfile from "@/components/OpsPumpsProfile";
import ByLocationTable from "@/components/ByLocationTable";
import { Tabs } from "@/components/Tabs";

import EnergyEfficiencyPage from "@/components/EnergyEfficiencyPage";
import ReliabilityPage from "@/components/ReliabilityPage";
import ProcesoCalidad from "@/components/ProcesoCalidad";

import { loadDashboard } from "@/data/loadFromApi";
import { k } from "@/utils/format";
import { useLiveOps } from "@/hooks/useLiveOps";
import { listPumps, listTanks } from "@/api/graphs";

import { deriveLocOptions, mergeLocOptions } from "./helpers/locations";
import { usePlayback } from "./hooks/usePlayback";
import { useAudit } from "./hooks/useAudit";
import PlaybackControls from "./components/PlaybackControls";
import BaseSelectors from "./components/BaseSelectors";
import AuditPanel from "./components/AuditPanel";

import type { LocOpt, PumpInfo, TankInfo } from "./types";

type CombinedOperationEvent = {
  id: string;
  kind: "pump" | "tank";
  tsMs: number;
  ts: string;
  entityName: string;
  locationName?: string | null;
  label: string;
  detail?: string | null;
  severity?: string | null;
  durationLabel?: string | null;
  value?: number | null;
  limitValue?: number | null;
};

function cleanText(v: any): string {
  if (v == null) return "";
  return String(v)
    .replaceAll("crÃ­tico", "crítico")
    .replaceAll("CrÃ­tico", "Crítico")
    .replaceAll("mÃ¡ximo", "máximo")
    .replaceAll("MÃ¡ximo", "Máximo")
    .replaceAll("mÃ­nimo", "mínimo")
    .replaceAll("MÃ­nimo", "Mínimo");
}

function fmtPct(v: any, decimals = 1) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "--";
  return `${n.toFixed(decimals)}%`;
}

function fmtLevel(v: any) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "--";
  return `${n.toFixed(2)}%`;
}

function fmtShortTime(tsMs?: number | null) {
  if (!tsMs || !Number.isFinite(tsMs)) return "--";
  return new Date(tsMs).toLocaleTimeString("es-AR", {
    timeZone: "America/Argentina/Buenos_Aires",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function fmtDateTime(tsMs?: number | null) {
  if (!tsMs || !Number.isFinite(tsMs)) return "--";
  return new Date(tsMs).toLocaleString("es-AR", {
    timeZone: "America/Argentina/Buenos_Aires",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function severityClass(severity?: string | null) {
  const s = String(severity ?? "").toLowerCase();

  if (s === "critical") {
    return "border-red-200 bg-red-50 text-red-700";
  }

  if (s === "warning") {
    return "border-amber-200 bg-amber-50 text-amber-700";
  }

  if (s === "info") {
    return "border-blue-200 bg-blue-50 text-blue-700";
  }

  return "border-slate-200 bg-slate-50 text-slate-700";
}

function statusPillClass(status?: string | null) {
  const s = String(status ?? "").toLowerCase();

  if (
    s.includes("sin comunicación") ||
    s.includes("crítico") ||
    s.includes("critico") ||
    s.includes("baja disponibilidad") ||
    s.includes("ciclado severo")
  ) {
    return "bg-red-100 text-red-700";
  }

  if (
    s.includes("alerta") ||
    s.includes("alto") ||
    s.includes("bajo") ||
    s.includes("utilización") ||
    s.includes("utilizacion")
  ) {
    return "bg-amber-100 text-amber-700";
  }

  if (s.includes("encendida") || s.includes("run") || s.includes("online")) {
    return "bg-emerald-100 text-emerald-700";
  }

  return "bg-slate-100 text-slate-700";
}

function MiniBadge({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium ${className}`}
    >
      {children}
    </span>
  );
}

function OperationEventFeed({
  events,
  loading,
}: {
  events: CombinedOperationEvent[];
  loading?: boolean;
}) {
  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="text-base">Eventos operativos recientes</CardTitle>
          {loading && (
            <span className="text-xs text-slate-400">Actualizando...</span>
          )}
        </div>
      </CardHeader>

      <CardContent>
        {events.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">
            No hay eventos recientes para el filtro actual.
          </div>
        ) : (
          <div className="space-y-2">
            {events.slice(0, 14).map((ev) => (
              <div
                key={ev.id}
                className={`rounded-xl border p-3 ${severityClass(ev.severity)}`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">
                        {fmtShortTime(ev.tsMs)}
                      </span>
                      <MiniBadge
                        className={
                          ev.kind === "tank"
                            ? "bg-sky-100 text-sky-700"
                            : "bg-emerald-100 text-emerald-700"
                        }
                      >
                        {ev.kind === "tank" ? "Tanque" : "Bomba"}
                      </MiniBadge>
                      <span className="font-medium">{ev.entityName}</span>
                    </div>

                    <div className="mt-1 text-sm">
                      {cleanText(ev.label)}
                      {ev.value != null && (
                        <span className="ml-1 font-semibold">
                          {fmtLevel(ev.value)}
                        </span>
                      )}
                      {ev.limitValue != null && (
                        <span className="ml-1 opacity-75">
                          límite {fmtLevel(ev.limitValue)}
                        </span>
                      )}
                    </div>

                    {ev.locationName && (
                      <div className="mt-1 text-xs opacity-70">
                        {ev.locationName}
                      </div>
                    )}
                  </div>

                  <div className="text-right text-xs opacity-75">
                    <div>{fmtDateTime(ev.tsMs)}</div>
                    {ev.durationLabel && <div>{ev.durationLabel}</div>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PumpHealthTable({ items }: { items: any[] }) {
  const rows = (items ?? []).slice(0, 10);

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Estado de bombas</CardTitle>
      </CardHeader>

      <CardContent>
        {rows.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">
            Sin datos de bombas para el filtro actual.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase tracking-wide text-slate-400">
                  <th className="py-2 pr-3">Bomba</th>
                  <th className="py-2 pr-3">Ubicación</th>
                  <th className="py-2 pr-3">Estado</th>
                  <th className="py-2 pr-3">Online</th>
                  <th className="py-2 pr-3 text-right">Arr.</th>
                  <th className="py-2 pr-3 text-right">Disp.</th>
                  <th className="py-2 pr-3">Operativo</th>
                </tr>
              </thead>

              <tbody>
                {rows.map((r) => (
                  <tr key={r.pump_id} className="border-b last:border-b-0">
                    <td className="py-2 pr-3 font-medium">
                      {r.pump_name ?? `Bomba ${r.pump_id}`}
                    </td>
                    <td className="py-2 pr-3 text-slate-500">
                      {r.location_name ?? "--"}
                    </td>
                    <td className="py-2 pr-3">
                      <MiniBadge
                        className={
                          r.current_state === "run"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-slate-100 text-slate-700"
                        }
                      >
                        {r.current_state_label ?? r.current_state ?? "--"}
                      </MiniBadge>
                    </td>
                    <td className="py-2 pr-3">
                      <MiniBadge
                        className={
                          r.online
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-red-100 text-red-700"
                        }
                      >
                        {r.online ? "Online" : "Offline"}
                      </MiniBadge>
                    </td>
                    <td className="py-2 pr-3 text-right">
                      {Number(r.starts_24h ?? 0)}
                    </td>
                    <td className="py-2 pr-3 text-right">
                      {fmtPct(r.availability_pct_24h)}
                    </td>
                    <td className="py-2 pr-3">
                      <MiniBadge className={statusPillClass(r.estado_operativo)}>
                        {cleanText(r.estado_operativo ?? "normal")}
                      </MiniBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TankHealthTable({ items }: { items: any[] }) {
  const rows = (items ?? []).slice(0, 10);

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Estado de tanques</CardTitle>
      </CardHeader>

      <CardContent>
        {rows.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">
            Sin datos de tanques para el filtro actual.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase tracking-wide text-slate-400">
                  <th className="py-2 pr-3">Tanque</th>
                  <th className="py-2 pr-3">Ubicación</th>
                  <th className="py-2 pr-3 text-right">Actual</th>
                  <th className="py-2 pr-3 text-right">Mín. 24h</th>
                  <th className="py-2 pr-3 text-right">Máx. 24h</th>
                  <th className="py-2 pr-3">Online</th>
                  <th className="py-2 pr-3">Operativo</th>
                </tr>
              </thead>

              <tbody>
                {rows.map((r) => (
                  <tr key={r.tank_id} className="border-b last:border-b-0">
                    <td className="py-2 pr-3 font-medium">
                      {r.tank_name ?? `Tanque ${r.tank_id}`}
                    </td>
                    <td className="py-2 pr-3 text-slate-500">
                      {r.location_name ?? "--"}
                    </td>
                    <td className="py-2 pr-3 text-right">
                      {fmtLevel(r.current_level)}
                    </td>
                    <td className="py-2 pr-3 text-right">
                      {fmtLevel(r.min_24h)}
                    </td>
                    <td className="py-2 pr-3 text-right">
                      {fmtLevel(r.max_24h)}
                    </td>
                    <td className="py-2 pr-3">
                      <MiniBadge
                        className={
                          r.online
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-red-100 text-red-700"
                        }
                      >
                        {r.online ? "Online" : "Offline"}
                      </MiniBadge>
                    </td>
                    <td className="py-2 pr-3">
                      <MiniBadge className={statusPillClass(r.estado_operativo)}>
                        {cleanText(r.estado_operativo ?? "normal")}
                      </MiniBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Widget() {
  const [live, setLive] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("operacion");

  // Ubicación BASE
  const [loc, setLoc] = useState<number | "all">("all");
  const [locOptionsAll, setLocOptionsAll] = useState<LocOpt[]>([]);
  const locId = loc === "all" ? undefined : Number(loc);

  // Selectores BASE
  const [pumpOptions, setPumpOptions] = useState<PumpInfo[]>([]);
  const [tankOptions, setTankOptions] = useState<TankInfo[]>([]);
  const [selectedPumpIds, setSelectedPumpIds] = useState<number[] | "all">("all");
  const [selectedTankIds, setSelectedTankIds] = useState<number[] | "all">("all");

  // Snapshot KPI/tabla
  useEffect(() => {
    let mounted = true;

    (async () => {
      setLoading(true);

      try {
        const data = await loadDashboard(loc);
        if (!mounted) return;

        setLive(data);

        const optsNow = deriveLocOptions(data?.locations, data?.byLocation);
        setLocOptionsAll((prev) => mergeLocOptions(prev, optsNow));
      } catch (e) {
        console.error(e);
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [loc]);

  // Cargar bombas/tanques BASE
  useEffect(() => {
    let mounted = true;

    setPumpOptions([]);
    setTankOptions([]);
    setSelectedPumpIds("all");
    setSelectedTankIds("all");

    (async () => {
      try {
        const [p, t] = await Promise.all([
          listPumps({ locationId: locId }),
          listTanks({ locationId: locId }),
        ]);

        if (!mounted) return;

        setPumpOptions(Array.isArray(p) ? (p as PumpInfo[]) : []);
        setTankOptions(Array.isArray(t) ? (t as TankInfo[]) : []);
      } catch (e) {
        if (!mounted) return;
        console.error("[filters] list error:", e);
        setPumpOptions([]);
        setTankOptions([]);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [locId]);

  // Polling: operación frecuente; resto suave
  const pollMs = tab === "operacion" ? 15_000 : 10 * 60_000;

  // Operación PRO 24h, 1 minuto
  const liveSync = useLiveOps({
    locationId: locId,
    periodHours: 24,
    bucket: "1min",
    pollMs,
    pumpIds: selectedPumpIds === "all" ? undefined : selectedPumpIds,
    tankIds: selectedTankIds === "all" ? undefined : selectedTankIds,
    loadPumpTimeline: false,
    loadPumpEvents: true,
    loadTankEvents: true,
    limitEvents: 500,
  });

  // Playback + dominio + series
  const playback = usePlayback({
    locId,
    tab,
    liveWindow: liveSync.window,
    livePumpTs: liveSync.pumpTs,
    liveTankTs: liveSync.tankTs,
    selectedPumpIds,
    selectedTankIds,
  });

  // Auditoría
  const [auditEnabled, setAuditEnabled] = useState(false);
  const [auditLoc, setAuditLoc] = useState<number | "">("");

  const audit = useAudit({
    enabled: auditEnabled,
    auditLoc,
    domain: playback.domain,
  });

  // Si se cierra Auditoría, apagamos playback y volvemos a Live
  useEffect(() => {
    if (!auditEnabled) playback.setPlayEnabled(false);
  }, [auditEnabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // =========================
  // KPIs / tabla legacy
  // =========================

  const byLocation = useMemo(
    () => (Array.isArray(live?.byLocation) ? live.byLocation : []),
    [live?.byLocation]
  );

  const byLocationFiltered = useMemo(() => {
    if (locId == null) return byLocation;
    return byLocation.filter((r: any) => Number(r?.location_id) === locId);
  }, [byLocation, locId]);

  const kpis = useMemo(() => {
    let tanks = 0;
    let pumps = 0;

    for (const r of Array.isArray(byLocationFiltered) ? byLocationFiltered : []) {
      tanks += Number(r?.tanks_count ?? 0);
      pumps += Number(r?.pumps_count ?? 0);
    }

    return { tanks, pumps };
  }, [byLocationFiltered]);

  const tankSummary = liveSync.tanksSummary?.summary;
  const pumpSummary = liveSync.pumpsSummary?.summary;

  const tankHealthRows = useMemo(() => {
    const rows = liveSync.tanksSummary?.items ?? [];

    return [...rows].sort((a: any, b: any) => {
      const score = (r: any) => {
        const sev = String(r?.severity ?? "").toLowerCase();
        const estado = String(r?.estado_operativo ?? "").toLowerCase();

        if (!r?.online) return 0;
        if (sev === "critical") return 1;
        if (estado.includes("crítico") || estado.includes("critico")) return 2;
        if (sev === "warning") return 3;
        if (estado !== "normal") return 4;

        return 9;
      };

      return score(a) - score(b);
    });
  }, [liveSync.tanksSummary?.items]);

  const pumpHealthRows = useMemo(() => {
    const rows = liveSync.pumpsSummary?.items ?? [];

    return [...rows].sort((a: any, b: any) => {
      const score = (r: any) => {
        const estado = String(r?.estado_operativo ?? "").toLowerCase();

        if (!r?.online) return 0;
        if (estado.includes("ciclado")) return 1;
        if (estado.includes("baja")) return 2;
        if (estado.includes("sin marcha")) return 3;
        if (estado.includes("alta")) return 4;

        return 9;
      };

      return score(a) - score(b);
    });
  }, [liveSync.pumpsSummary?.items]);

  const combinedEvents = useMemo<CombinedOperationEvent[]>(() => {
    const pumpEvents =
      liveSync.pumpEvents?.items?.map((e: any) => ({
        id: `pump-${e.id}`,
        kind: "pump" as const,
        tsMs: Number(e.event_ts_ms ?? new Date(e.event_ts).getTime()),
        ts: e.event_ts,
        entityName: e.pump_name ?? `Bomba ${e.pump_id}`,
        locationName: e.location_name,
        label: e.state_label ?? e.state ?? "Evento de bomba",
        detail: e.state,
        severity: e.severity,
        durationLabel: e.duration_label,
        value: null,
        limitValue: null,
      })) ?? [];

    const tankEvents =
      liveSync.tankEvents?.items?.map((e: any) => ({
        id: `tank-${e.id}`,
        kind: "tank" as const,
        tsMs: Number(e.event_ts_ms ?? new Date(e.event_ts).getTime()),
        ts: e.event_ts,
        entityName: e.tank_name ?? `Tanque ${e.tank_id}`,
        locationName: e.location_name,
        label: e.event_label ?? e.event_type ?? "Evento de tanque",
        detail: e.event_type,
        severity: e.severity,
        durationLabel: e.duration_label,
        value: e.detected_value,
        limitValue: e.configured_limit,
      })) ?? [];

    return [...pumpEvents, ...tankEvents]
      .filter((e) => Number.isFinite(e.tsMs))
      .sort((a, b) => b.tsMs - a.tsMs);
  }, [liveSync.pumpEvents?.items, liveSync.tankEvents?.items]);

  const totalPumpsCap = useMemo(
    () => pumpSummary?.pumps_total ?? liveSync.pumpsTotal ?? (kpis.pumps || undefined),
    [pumpSummary?.pumps_total, liveSync.pumpsTotal, kpis.pumps]
  );

  const auditPumpsCap = useMemo(
    () => (audit.pumpOptions?.length || 0) || undefined,
    [audit.pumpOptions]
  );

  const operationLoading = Boolean(liveSync.meta?.isLoading || loading);

  return (
    <div className="space-y-6 p-6">
      {/* Filtros superiores */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Ubicación:</span>

          <select
            className="rounded-xl border p-2 text-sm"
            value={loc === "all" ? "all" : String(loc)}
            onChange={(e) =>
              setLoc(e.target.value === "all" ? "all" : Number(e.target.value))
            }
          >
            <option value="all">Todas</option>
            {locOptionsAll.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
          </select>
        </div>

        {tab === "operacion" && (
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <MiniBadge className="bg-slate-100 text-slate-600">
              24 h
            </MiniBadge>
            <MiniBadge className="bg-slate-100 text-slate-600">
              bucket {liveSync.meta?.bucket ?? "1min"}
            </MiniBadge>
            {liveSync.meta?.lastOkAt && (
              <span>
                actualizado {fmtShortTime(liveSync.meta.lastOkAt)}
              </span>
            )}
            {liveSync.meta?.lastErr && (
              <span className="text-red-500">
                {liveSync.meta.lastErr}
              </span>
            )}
          </div>
        )}
      </div>

      {(pumpOptions.length > 0 || tankOptions.length > 0) && (
        <BaseSelectors
          pumpOptions={pumpOptions}
          tankOptions={tankOptions}
          selectedPumpIds={selectedPumpIds}
          setSelectedPumpIds={setSelectedPumpIds}
          selectedTankIds={selectedTankIds}
          setSelectedTankIds={setSelectedTankIds}
        />
      )}

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "operacion", label: "Operación" },
          { id: "eficiencia", label: "Eficiencia energética" },
          { id: "confiabilidad", label: "Operación y confiabilidad" },
          { id: "calidad", label: "Proceso y calidad del agua" },
          { id: "gestion", label: "Gestión global" },
        ]}
      />

      {tab === "operacion" && (
        <>
          {/* KPIs PRO */}
          <section className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <KPI
              label="Tanques online"
              value={`${k(tankSummary?.tanks_online ?? liveSync.tanksConnected ?? 0)} / ${k(
                tankSummary?.tanks_total ?? kpis.tanks
              )}`}
            />

            <KPI
              label="Tanques en alarma"
              value={k(tankSummary?.tanks_in_alarm ?? 0)}
            />

            <KPI
              label="Nivel mín. 24h"
              value={fmtLevel(tankSummary?.min_level_24h)}
            />

            <KPI
              label="Bombas ON"
              value={`${k(pumpSummary?.pumps_running ?? 0)} / ${k(
                pumpSummary?.pumps_total ?? liveSync.pumpsTotal ?? kpis.pumps
              )}`}
            />

            <KPI
              label="Sin comunicación"
              value={k(
                (pumpSummary?.pumps_offline ?? 0) +
                  (tankSummary?.tanks_offline ?? 0)
              )}
            />

            <KPI
              label="Arranques 24h"
              value={k(pumpSummary?.starts_24h ?? 0)}
            />
          </section>

          <AuditPanel
            auditEnabled={auditEnabled}
            setAuditEnabled={setAuditEnabled}
            locOptions={locOptionsAll}
            auditLoc={auditLoc}
            setAuditLoc={setAuditLoc}
            tankOptions={audit.tankOptions}
            pumpOptions={audit.pumpOptions}
            selectedTankIds={audit.selectedTankIds}
            setSelectedTankIds={audit.setSelectedTankIds}
            selectedPumpIds={audit.selectedPumpIds}
            setSelectedPumpIds={audit.setSelectedPumpIds}
            playbackControls={
              <PlaybackControls
                disabled={!locId}
                playEnabled={playback.playEnabled}
                setPlayEnabled={playback.setPlayEnabled}
                playing={playback.playing}
                setPlaying={playback.setPlaying}
                playFinMin={playback.playFinMin}
                setPlayFinMin={playback.setPlayFinMin}
                MIN_OFFSET_MIN={playback.MIN_OFFSET_MIN}
                MAX_OFFSET_MIN={playback.MAX_OFFSET_MIN}
                setDragging={playback.setDragging}
                startLabel={playback.startLabel}
                endLabel={playback.endLabel}
              />
            }
          />

          {/* Gráficos actuales alimentados con series nuevas */}
          <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <TankLevelChart
              ts={playback.tankTs}
              syncId="op-sync"
              title={
                playback.playEnabled
                  ? "Nivel de tanques (Playback 24 h)"
                  : "Nivel de tanques (24h • promedio/min/máx)"
              }
              tz="America/Argentina/Buenos_Aires"
              xDomain={playback.domain}
              xTicks={playback.ticks}
              hoverX={null}
              onHoverX={() => {}}
              showBrushIf={120}
            />

           <OpsPumpsProfile
  pumpsTs={playback.pumpTs}
  timelineItems={liveSync.pumpTimeline?.items ?? []}
  max={totalPumpsCap}
  syncId="op-sync"
  title="Bombas ON (24h • 1 minuto)"
  tz="America/Argentina/Buenos_Aires"
  xDomain={playback.domain}
  xTicks={playback.ticks}
  hoverX={null}
  onHoverX={() => {}}
/>
          </section>

          {/* Estado operativo + eventos */}
          <section className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            <div className="xl:col-span-2">
              <OperationEventFeed
                events={combinedEvents}
                loading={operationLoading}
              />
            </div>

            <Card className="rounded-2xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Síntesis operativa</CardTitle>
              </CardHeader>

              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="text-slate-500">Eventos activos tanques</span>
                    <span className="font-semibold">
                      {k(tankSummary?.active_events ?? 0)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="text-slate-500">Máximo nivel 24h</span>
                    <span className="font-semibold">
                      {fmtLevel(tankSummary?.max_level_24h)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="text-slate-500">Bombas con alerta</span>
                    <span className="font-semibold">
                      {k(pumpSummary?.pumps_with_alert ?? 0)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="text-slate-500">Disponibilidad promedio</span>
                    <span className="font-semibold">
                      {fmtPct(pumpSummary?.avg_availability_pct_24h)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Comunicación promedio</span>
                    <span className="font-semibold">
                      {fmtPct(pumpSummary?.avg_online_pct_24h)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="grid grid-cols-1 gap-4 xl:grid-cols-2">
            <TankHealthTable items={tankHealthRows} />
            <PumpHealthTable items={pumpHealthRows} />
          </section>

          {auditEnabled && auditLoc !== "" && (
            <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <TankLevelChart
                ts={audit.tankTs ?? { timestamps: [], level_percent: [] }}
                syncId="op-sync"
                title="Nivel del tanque – Auditoría"
                tz="America/Argentina/Buenos_Aires"
                xDomain={playback.domain}
                xTicks={playback.ticks}
                hoverX={null}
                onHoverX={() => {}}
              />

              <OpsPumpsProfile
                pumpsTs={audit.pumpTs ?? { timestamps: [], is_on: [] }}
                max={auditPumpsCap}
                syncId="op-sync"
                title="Bombas ON – Auditoría"
                tz="America/Argentina/Buenos_Aires"
                xDomain={playback.domain}
                xTicks={playback.ticks}
                hoverX={null}
                onHoverX={() => {}}
              />
            </section>
          )}
        </>
      )}

      {tab === "eficiencia" && (
        <section>
          <EnergyEfficiencyPage
            locationId={locId}
            tz="America/Argentina/Buenos_Aires"
          />
        </section>
      )}

      {tab === "confiabilidad" && (
        <ReliabilityPage
          locationId={loc === "all" ? "all" : locId ?? "all"}
          selectedPumpIds={selectedPumpIds}
          selectedTankIds={selectedTankIds}
          thresholdLow={90}
        />
      )}

      {tab === "calidad" && (
        <section>
          <ProcesoCalidad />
        </section>
      )}

      {tab === "gestion" && (
        <section>
          <Card className="rounded-2xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Gestión global</CardTitle>
            </CardHeader>

            <CardContent>
              <div className="text-sm text-gray-600">
                Espacio reservado para indicadores globales, seguimiento y administración.
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      <section>
        <Card className="rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base">Resumen por ubicación</CardTitle>
          </CardHeader>

          <CardContent>
            <ByLocationTable rows={byLocationFiltered} />
          </CardContent>
        </Card>
      </section>
    </div>
  );
}