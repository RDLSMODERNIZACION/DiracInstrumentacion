import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceLine,
  ReferenceDot,
  Brush,
} from "recharts";

type MaybeNum = number | string | null | undefined;

export type PumpsTs = {
  timestamps?: MaybeNum[];

  /**
   * Cantidad de bombas encendidas por minuto/bucket.
   * Nombre viejo mantenido por compatibilidad.
   */
  is_on?: (number | boolean | string | null)[];

  /**
   * Nuevas series operativas.
   * No se grafican todas por defecto para evitar confusión,
   * pero sí se usan en tooltip y resumen.
   */
  pumps_off?: MaybeNum[];
  pumps_online?: MaybeNum[];
  pumps_offline?: MaybeNum[];
} | null;

type ChartRow = {
  ms: number;
  on: number | null;
  off: number | null;
  online: number | null;
  offline: number | null;
  onPct: number | null;
  onlinePct: number | null;
  onCmp?: number | null;
};

function toMs(x: MaybeNum): number {
  if (typeof x === "number") {
    return x > 2_000_000_000 ? x : x * 1000;
  }

  if (typeof x === "string") {
    const n = Number(x);

    if (Number.isFinite(n)) {
      return n > 2_000_000_000 ? n : n * 1000;
    }

    const t = Date.parse(x);

    if (Number.isFinite(t)) {
      return t;
    }
  }

  return NaN;
}

function toNum(x: any): number | null {
  if (x === null || x === undefined || x === "") return null;

  if (x === true) return 1;
  if (x === false) return 0;

  const n = typeof x === "string" ? Number(x.replace(",", ".")) : Number(x);

  return Number.isFinite(n) ? n : null;
}

function fmtTime(ms: number, tz: string) {
  try {
    return new Intl.DateTimeFormat("es-AR", {
      timeZone: tz,
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(ms);
  } catch {
    const d = new Date(ms);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `${hh}:${mm}`;
  }
}

function fmtDateTime(ms: number, tz: string) {
  try {
    return new Intl.DateTimeFormat("es-AR", {
      timeZone: tz,
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(ms);
  } catch {
    return new Date(ms).toLocaleString();
  }
}

function fmtInt(v: any) {
  const n = toNum(v);
  if (n === null) return "--";
  return Math.round(n).toLocaleString("es-AR");
}

function fmtNum(v: any, decimals = 1) {
  const n = toNum(v);
  if (n === null) return "--";
  return n.toLocaleString("es-AR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function fmtPct(v: any, decimals = 1) {
  const n = toNum(v);
  if (n === null) return "--";
  return `${n.toFixed(decimals)}%`;
}

function lastValid(rows: ChartRow[], key: keyof ChartRow): number | null {
  for (let i = rows.length - 1; i >= 0; i--) {
    const v = rows[i][key];

    if (typeof v === "number" && Number.isFinite(v)) {
      return v;
    }
  }

  return null;
}

function averageValid(rows: ChartRow[], key: keyof ChartRow): number | null {
  const xs: number[] = [];

  for (const r of rows) {
    const v = r[key];

    if (typeof v === "number" && Number.isFinite(v)) {
      xs.push(v);
    }
  }

  if (!xs.length) return null;

  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function getMaxPoint(rows: ChartRow[]) {
  let best: { ms: number; value: number } | null = null;

  for (const r of rows) {
    const value = r.on;

    if (value === null || !Number.isFinite(value)) continue;

    if (!best || value > best.value) {
      best = { ms: r.ms, value };
    }
  }

  return best;
}

function buildRows(pumpsTs?: PumpsTs, max?: number): ChartRow[] {
  const timestamps = pumpsTs?.timestamps ?? [];
  const onValues = pumpsTs?.is_on ?? [];
  const offValues = pumpsTs?.pumps_off ?? [];
  const onlineValues = pumpsTs?.pumps_online ?? [];
  const offlineValues = pumpsTs?.pumps_offline ?? [];

  const n = Math.min(
    timestamps.length,
    Math.max(
      onValues.length,
      offValues.length,
      onlineValues.length,
      offlineValues.length
    )
  );

  const rows: ChartRow[] = [];

  for (let i = 0; i < n; i++) {
    const ms = toMs(timestamps[i]);

    if (!Number.isFinite(ms)) continue;

    const onRaw = toNum(onValues[i]);
    const offRaw = toNum(offValues[i]);
    const onlineRaw = toNum(onlineValues[i]);
    const offlineRaw = toNum(offlineValues[i]);

    let on = onRaw === null ? null : Math.max(0, onRaw);

    if (typeof max === "number" && Number.isFinite(max) && on !== null) {
      on = Math.min(on, max);
    }

    let off = offRaw === null ? null : Math.max(0, offRaw);

    if (
      off === null &&
      typeof max === "number" &&
      Number.isFinite(max) &&
      on !== null
    ) {
      off = Math.max(0, max - on);
    }

    const online =
      onlineRaw !== null
        ? Math.max(0, onlineRaw)
        : typeof max === "number" && Number.isFinite(max)
          ? max
          : on !== null && off !== null
            ? on + off
            : null;

    const offline =
      offlineRaw !== null
        ? Math.max(0, offlineRaw)
        : typeof max === "number" && Number.isFinite(max) && online !== null
          ? Math.max(0, max - online)
          : null;

    const total =
      typeof max === "number" && Number.isFinite(max)
        ? max
        : on !== null && off !== null
          ? on + off
          : online !== null && offline !== null
            ? online + offline
            : null;

    const onPct =
      total && total > 0 && on !== null
        ? (on / total) * 100
        : null;

    const onlinePct =
      total && total > 0 && online !== null
        ? (online / total) * 100
        : null;

    rows.push({
      ms,
      on,
      off,
      online,
      offline,
      onPct,
      onlinePct,
    });
  }

  return rows.sort((a, b) => a.ms - b.ms);
}

function CustomTooltip({
  active,
  label,
  payload,
  tz,
}: {
  active?: boolean;
  label?: any;
  payload?: any[];
  tz: string;
}) {
  if (!active || !payload?.length) return null;

  const row = payload?.[0]?.payload as ChartRow | undefined;

  if (!row) return null;

  return (
    <div className="rounded-xl border border-slate-200 bg-white/95 p-3 text-xs shadow-lg">
      <div className="mb-2 font-semibold text-slate-700">
        {fmtDateTime(Number(label ?? row.ms), tz)}
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between gap-8">
          <span className="text-slate-500">Bombas encendidas</span>
          <span className="font-semibold text-emerald-700">
            {fmtInt(row.on)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-8">
          <span className="text-slate-500">Bombas apagadas</span>
          <span className="font-semibold text-slate-700">
            {fmtInt(row.off)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-8">
          <span className="text-slate-500">Online</span>
          <span className="font-semibold text-blue-700">
            {fmtInt(row.online)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-8">
          <span className="text-slate-500">Sin comunicación</span>
          <span className="font-semibold text-red-700">
            {fmtInt(row.offline)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-8 border-t pt-1">
          <span className="text-slate-500">% encendidas</span>
          <span className="font-semibold text-slate-800">
            {fmtPct(row.onPct)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-8">
          <span className="text-slate-500">% comunicación</span>
          <span className="font-semibold text-slate-800">
            {fmtPct(row.onlinePct)}
          </span>
        </div>

        {row.onCmp !== undefined && (
          <div className="flex items-center justify-between gap-8 border-t pt-1">
            <span className="text-slate-500">Auditoría ON</span>
            <span className="font-semibold text-slate-800">
              {fmtInt(row.onCmp)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

export default function OpsPumpsProfile({
  pumpsTs,
  comparePumpsTs,
  compareLabel = "Auditoría",
  max,
  syncId,
  title = "Bombas ON",
  tz,
  xDomain,
  xTicks,
  hoverX,
  onHoverX,
  showBrushIf = 0,
}: {
  pumpsTs?: PumpsTs;
  comparePumpsTs?: PumpsTs;
  compareLabel?: string;
  max?: number;
  syncId?: string;
  title?: string;
  tz: string;
  xDomain?: [number, number];
  xTicks?: number[];
  hoverX?: number | null;
  onHoverX?: (x: number | null) => void;

  /**
   * Si la cantidad de puntos supera este número, muestra Brush.
   */
  showBrushIf?: number;
}) {
  const data = useMemo(() => buildRows(pumpsTs, max), [pumpsTs, max]);

  const dataCmp = useMemo(() => {
    if (!comparePumpsTs) return null;

    const timestamps = comparePumpsTs.timestamps ?? [];
    const values = comparePumpsTs.is_on ?? [];
    const n = Math.min(timestamps.length, values.length);

    const rows: { ms: number; onCmp: number | null }[] = [];

    for (let i = 0; i < n; i++) {
      const ms = toMs(timestamps[i]);

      if (!Number.isFinite(ms)) continue;

      rows.push({
        ms,
        onCmp: toNum(values[i]),
      });
    }

    return rows;
  }, [comparePumpsTs]);

  const merged = useMemo(() => {
    if (!dataCmp) return data;

    const map = new Map<number, ChartRow>();

    for (const r of data) {
      map.set(r.ms, { ...r });
    }

    for (const r of dataCmp) {
      const cur = map.get(r.ms);

      if (cur) {
        cur.onCmp = r.onCmp;
      } else {
        map.set(r.ms, {
          ms: r.ms,
          on: null,
          off: null,
          online: null,
          offline: null,
          onPct: null,
          onlinePct: null,
          onCmp: r.onCmp,
        });
      }
    }

    return Array.from(map.values()).sort((a, b) => a.ms - b.ms);
  }, [data, dataCmp]);

  const summary = useMemo(() => {
    const currentOn = lastValid(merged, "on");
    const currentOff = lastValid(merged, "off");
    const currentOnline = lastValid(merged, "online");
    const currentOffline = lastValid(merged, "offline");
    const avgOn = averageValid(merged, "on");
    const avgOnPct = averageValid(merged, "onPct");
    const avgOnlinePct = averageValid(merged, "onlinePct");
    const maxPoint = getMaxPoint(merged);

    return {
      currentOn,
      currentOff,
      currentOnline,
      currentOffline,
      avgOn,
      avgOnPct,
      avgOnlinePct,
      maxPoint,
      points: merged.length,
    };
  }, [merged]);

  const hasData = merged.length > 0;

  const hasOffline = useMemo(
    () => merged.some((r) => (r.offline ?? 0) > 0),
    [merged]
  );

  const yMax = useMemo(() => {
    const maxOn = Math.max(...merged.map((d) => Number(d.on ?? 0)), 0);
    const maxOffline = hasOffline
      ? Math.max(...merged.map((d) => Number(d.offline ?? 0)), 0)
      : 0;
    const maxCmp = Math.max(...merged.map((d) => Number(d.onCmp ?? 0)), 0);

    return Math.max(max ?? 0, maxOn, maxOffline, maxCmp, 1);
  }, [merged, max, hasOffline]);

  const shouldShowBrush =
    showBrushIf > 0 && merged.length > showBrushIf && !xDomain;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
      <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-slate-700">{title}</div>
          <div className="mt-1 text-xs text-slate-400">
            Lectura simple: cantidad de bombas encendidas en las últimas 24 h.
          </div>
        </div>

        <div className="flex flex-wrap gap-2 text-xs">
          <div className="rounded-full bg-emerald-50 px-2 py-1 text-emerald-700">
            ON actual:{" "}
            <span className="font-semibold">{fmtInt(summary.currentOn)}</span>
          </div>

          <div className="rounded-full bg-slate-100 px-2 py-1 text-slate-600">
            OFF:{" "}
            <span className="font-semibold">{fmtInt(summary.currentOff)}</span>
          </div>

          {hasOffline && (
            <div className="rounded-full bg-red-50 px-2 py-1 text-red-700">
              Offline:{" "}
              <span className="font-semibold">
                {fmtInt(summary.currentOffline)}
              </span>
            </div>
          )}

          <div className="rounded-full bg-blue-50 px-2 py-1 text-blue-700">
            Máx ON:{" "}
            <span className="font-semibold">
              {fmtInt(summary.maxPoint?.value)}
            </span>
          </div>
        </div>
      </div>

      <div className="h-72">
        {!hasData ? (
          <div className="flex h-full items-center justify-center rounded-xl bg-slate-50 text-sm text-slate-400">
            Sin datos de bombas para el filtro actual.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={merged}
              syncId={syncId}
              margin={{
                top: 12,
                right: 24,
                bottom: shouldShowBrush ? 18 : 4,
                left: 0,
              }}
              onMouseMove={(e: any) => {
                if (!onHoverX) return;

                const x = Number(e?.activeLabel);

                onHoverX(Number.isFinite(x) ? x : null);
              }}
              onMouseLeave={() => onHoverX && onHoverX(null)}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />

              <XAxis
                type="number"
                dataKey="ms"
                domain={(xDomain as any) ?? ["dataMin", "dataMax"]}
                ticks={xTicks as any}
                tickFormatter={(ms: any) =>
                  Number.isFinite(Number(ms)) ? fmtTime(Number(ms), tz) : ""
                }
                tick={{ fontSize: 11, fill: "#64748b" }}
                axisLine={{ stroke: "#cbd5e1" }}
                tickLine={{ stroke: "#cbd5e1" }}
              />

              <YAxis
                domain={[0, yMax]}
                allowDecimals={false}
                tick={{ fontSize: 11, fill: "#64748b" }}
                axisLine={{ stroke: "#cbd5e1" }}
                tickLine={{ stroke: "#cbd5e1" }}
                width={42}
              />

              <Tooltip
                content={(props: any) => <CustomTooltip {...props} tz={tz} />}
              />

              <Legend
                wrapperStyle={{ fontSize: 12 }}
                verticalAlign="top"
                height={28}
              />

              {/* Serie principal clara */}
              <Area
                type="stepAfter"
                dataKey="on"
                name="Bombas ON"
                stroke="#059669"
                fill="#bbf7d0"
                fillOpacity={0.5}
                strokeWidth={2.75}
                isAnimationActive={false}
                connectNulls
              />

              {/* Sólo se dibuja si realmente hay offline */}
              {hasOffline && (
                <Area
                  type="stepAfter"
                  dataKey="offline"
                  name="Sin comunicación"
                  stroke="#dc2626"
                  fill="#fecaca"
                  fillOpacity={0.35}
                  strokeWidth={2}
                  isAnimationActive={false}
                  connectNulls
                />
              )}

              {dataCmp && (
                <Line
                  type="stepAfter"
                  dataKey="onCmp"
                  name={`${compareLabel} ON`}
                  stroke="#0f172a"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                  connectNulls
                />
              )}

              {summary.maxPoint && (
                <ReferenceDot
                  x={summary.maxPoint.ms}
                  y={summary.maxPoint.value}
                  r={4}
                  fill="#059669"
                  stroke="#ffffff"
                  strokeWidth={2}
                  label={{
                    value: `Máx ${fmtInt(summary.maxPoint.value)}`,
                    position: "top",
                    fill: "#059669",
                    fontSize: 11,
                  }}
                />
              )}

              {typeof max === "number" && Number.isFinite(max) && max > 0 && (
                <ReferenceLine
                  y={max}
                  stroke="#94a3b8"
                  strokeDasharray="4 4"
                  label={{
                    value: `Total ${max}`,
                    position: "insideTopRight",
                    fill: "#64748b",
                    fontSize: 11,
                  }}
                />
              )}

              {hoverX ? (
                <ReferenceLine
                  x={hoverX}
                  stroke="#0f172a"
                  strokeWidth={1}
                  strokeOpacity={0.45}
                />
              ) : null}

              {shouldShowBrush && (
                <Brush
                  dataKey="ms"
                  height={18}
                  travellerWidth={8}
                  tickFormatter={(ms: any) =>
                    Number.isFinite(Number(ms)) ? fmtTime(Number(ms), tz) : ""
                  }
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        )}
      </div>

      {summary.maxPoint ? (
        <div className="mt-3 grid grid-cols-1 gap-2 text-xs sm:grid-cols-3">
          <div className="rounded-xl bg-emerald-50 px-3 py-2 text-emerald-700">
            Máximo ON:{" "}
            <span className="font-semibold">
              {fmtInt(summary.maxPoint.value)}
            </span>{" "}
            a las{" "}
            <span className="font-semibold">
              {fmtTime(summary.maxPoint.ms, tz)}
            </span>
          </div>

          <div className="rounded-xl bg-slate-50 px-3 py-2 text-slate-600">
            Promedio ON:{" "}
            <span className="font-semibold">{fmtNum(summary.avgOn)}</span>{" "}
            bombas
          </div>

          <div className="rounded-xl bg-blue-50 px-3 py-2 text-blue-700">
            Uso promedio:{" "}
            <span className="font-semibold">{fmtPct(summary.avgOnPct)}</span>
          </div>
        </div>
      ) : null}
    </div>
  );
}